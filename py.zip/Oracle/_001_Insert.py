# python -m pip install cx_oracle
import cx_Oracle

cx_Oracle.init_oracle_client(lib_dir="C:/MyPrograms/Databases/Oracle/instantclient_19_6")
# connect to database
conn = cx_Oracle.connect('c##pythonuser/python@ora19host/orcl')
cur = conn.cursor()
sql = "insert into STOCK values (1,'Apple',100)"
cur.execute(sql)

sql = "insert into STOCK values (2,'Mango',35)"
cur.execute(sql)

sql = "insert into STOCK values (3,'Grapes',40)"
cur.execute(sql)

sql = "insert into STOCK values (4,'Orange',80)"
cur.execute(sql)

conn.commit()
print("Inserted Successfully")
cur.close()
conn.close()
