import cx_Oracle

cx_Oracle.init_oracle_client(lib_dir="C:/MyPrograms/Databases/Oracle/instantclient_19_6")
# connect to database
conn = cx_Oracle.connect('c##pythonuser/python@ora19host/orcl')
cur = conn.cursor()
sql = "update STOCK set price = 110 where id = 1"
cur.execute(sql)
conn.commit()
print("Updated Successfully")
cur.close()
conn.close()
