import cx_Oracle

cx_Oracle.init_oracle_client(lib_dir="C:/MyPrograms/Databases/Oracle/instantclient_19_6")
# connect to database
conn = cx_Oracle.connect('c##pythonuser/python@ora19host/orcl')
#creating cursor for query execution
cur = conn.cursor()
sql = "select * from STOCK"
cur.execute(sql)

# res = cur.fetchone()
# print(res)
# print(res[0],res[1],res[2])
# res = cur.fetchone()
# print(res[0],res[1],res[2])

print('-'*35)
for (id,it,pr) in cur:
    print("| %5d | %-10s | %10.2f |" % (id,it,pr))
    print('-'*35)

cur.close()
conn.close()