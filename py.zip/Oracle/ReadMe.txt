MS SQL Server
======

CREATE TABLE STOCK(
	ID INT PRIMARY KEY,
	ITEM VARCHAR(50),
	PRICE FLOAT
)

python -m pip install cx_oracle
download Oracle client from "https://www.oracle.com/database/technologies/instant-client/downloads.html"

