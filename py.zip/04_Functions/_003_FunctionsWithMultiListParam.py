import sys

def read2D(lst2D,r,c):
	for i in range(0,r):
		lst = []
		for j in range(0,c):
			n = int(input('Enter (%d,%d) element: ' % (i+1,j+1)))
			lst.append(n)
		lst2D.append(lst) 


def print2D(lst2D):
	for r in lst2D:
		for e in r:
			if(e==0): sys.stdout.write('%5s' % ' ')
			else: sys.stdout.write('%5d' % e)
		print('\n')

def getRDia(lst2D):
	res = lst2D
	i = 0
	for r in lst2D:
		j = 0
		for e in r:
			if(i!=j): res[i][j] = 0
			j+=1
		i+=1
	return res

def myMsg(str):
	print()
	st = str.center(20,'*')
	print(('\n'+st+'\n').center(62,'*'),'\n')

lst_1 = []
m = int(input('Enter Row Size: '))
n = int(input('Enter Col Size: '))
read2D(lst_1,m,n)
myMsg(' Matrix ')
print2D(lst_1)
myMsg(' Diagonal ')
print2D(getRDia(lst_1))