# anonymous/lambda functions
# declared not in standard manner using def
# only single stattement is allowed

sum = lambda a,b : a+b

print('Sum = ',sum(20,10))