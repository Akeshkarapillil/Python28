def SimpleInt(p, n, r=10):
    si = p*n*r/100
    return si


a = SimpleInt(1000, 2, 7)
b = SimpleInt(1000, 2)

print('a = %d \nb= %d' % (a, b))
