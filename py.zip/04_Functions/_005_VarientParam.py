def sum(*nos):
    s = 0
    for x in nos:
        s += x
    return s


s1 = sum(10, 20, 30)
s2 = sum(1, 2, 5, 20)
print("s1 = ", s1)
print("s2 = ", s2)
