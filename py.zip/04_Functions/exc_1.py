def isPrime(n):
    for i in range(2, n):
        if n % i == 0:
            return 0
    return 1


'''
if isPrime(15): print('Prime')
else: print('not Prime')
'''


def primeEle(mylist):
    pr = []
    for n in mylist:
        if(isPrime(n)):
            pr.append(n)
    return pr


lst_n = [24, 31, 5, 11, 13, 45, 7]
lst_p = primeEle(lst_n)

print('Elements are: %s' % lst_n)
print('Prime Elements are: %s' % lst_p)
