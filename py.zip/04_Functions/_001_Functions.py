def fun_1():
	print('Welcome')

def fun_2(str):
	print('hi '+str)

def fact(n):
	f = 1
	for i in range(1,n+1):
		f*=i
	return f

fun_1()
fun_2('Daya')
print('Factorial of 4 is %d' % (fact(4)))
print('Factorial of 5 is %d' % (fact(n=5)))