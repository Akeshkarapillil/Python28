def fun_1(mylist,ele):
	mylist.append(ele)

lst_1 = [1,2,3,4]
print(lst_1)
fun_1(lst_1,5)
print(lst_1)