# The term broadcasting refers to
# the ability of NumPy to treat arrays of
# different shapes during arithmetic operations.

import numpy as np

a = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
b = np.array([[11, 22, 33], [44, 55, 66], [77, 88, 99]])

print("\n Array i\n",a)
print("\n Array ii\n",b)

print("\nBetween same size array arithmetic operation is easy")
print('\n a + b = \n',a+b)
# print('\n b - a = \n',b-a)
# print('\n a * b = \n',a*b)
# print('\n b / a = \n',b/a)
# print('\n b // a = \n',b//a)
# print('\n b ** a = \n',b**a)
# print('\n b % a = \n',b%a)

c = np.array([[1,2,3]])
print('\nArray iii\n',c)
o = '''
    Between different size array arithmetic operation is possible 
    beacause of broadcasting enabled in numpy
'''
print("\n"+o+"\n b + c = \n", b+c)