import numpy as np
import numpy.matlib as ml

# matlib.empty() function returns a new matrix without initializing the entries
print("\n empty((2, 2)) \n", ml.empty((2, 2)))

# numpy.matlib.zeros() function returns the matrix filled with zeros.
print("\n zeros((2,2)) \n", ml.zeros((2, 2)))

# numpy.matlib.ones() function returns the matrix filled with 1s.
print("\n ones((2,2)) \n", ml.ones((2, 2)))

# numpy.matlib.eye() function returns a matrix with 1
# along the diagonal elements and the zeros elsewhere.
# n -> Rows, M -> Columns, k -> Diagonal index
print("\n eye(n = 3, M = 4, k = 1) \n", ml.eye(n=3, M=4, k=1))

# numpy.matlib.identity() function returns the Identity matrix of the given size.
# An identity matrix is a square matrix with all diagonal elements as 1.
print("\n identity(3) \n", ml.identity(3))

#  numpy.matlib.rand() function returns a matrix of the given size
# filled with random values
print("\n rand(2,2) \n", ml.rand(2, 2))

'''
    a matrix is always two-dimensional, whereas ndarray is an n-dimensional array. 
    Both the objects are inter-convertible.
'''
i = np.matrix('1,2;3,4')
print("\n matrix('1,2;3,4') \n", i)
j = np.asarray(i)
print("\n asarray(i) \n", j)
k = np.asmatrix(j)
print("\n asmatrix(j) \n", k)
