import numpy as np

# numpy.arange(start, stop, step, dtype)
# (returns an ndarray object
# containing evenly spaced values within a given range)

x = np.arange(10, 20, 2)
print(x, '\n', '='*20)
# [10 12 14 16 18]

# numpy.linspace(start, stop, num, endpoint, retstep, dtype)
# similar to arange() function. In this function,
# instead of step size, the number of evenly spaced values
# between the interval is specified.
x = np.linspace(10, 20, 5)
print(x, '\n', '='*20)
# [10.  12.5 15.  17.5 20. ]

# numpy.logspace(start, stop, num, endpoint, base, dtype)
# returns an ndarray object that contains the numbers 
# that are evenly spaced on a log scale. Start and stop 
# endpoints of the scale are indices of the base, usually 10.
# start = base^start, stop = base^stop

x = np.logspace(1, 10, num=4,base=2)
print(x, '\n', '='*20)
# [   2.   16.  128. 1024.]

