import numpy as np

'''
    numpy.ndarray.byteswap() function toggles 
    between the two representations: bigendian 
    and little-endian. 

    A load word or store word instruction uses only one memory address. 
    The lowest address of the four bytes is used for the address of a 
    block of four contiguous bytes.

    Big Endian Byte Order: The most significant byte (the "big end") 
    of the data is placed at the byte with the lowest address. 
    The rest of the data is placed in order in the next three bytes in memory.

    Little Endian Byte Order: The least significant byte (the "little end") 
    of the data is placed at the byte with the lowest address. 
    The rest of the data is placed in order in the next three bytes in memory.
'''

a = np.array([1, 256, 8755], dtype=np.int16)
print("\n Array: \n", a)
print("\n Hexadecimal form: list(map(hex, a)) \n", list(map(hex, a)))
print("\n byteswap(True) \n", a.byteswap(True))
print("\n Hexadecimal form: list(map(hex, a)) \n", list(map(hex, a)))
