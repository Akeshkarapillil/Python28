import numpy as np

a = np.arange(2, 18, 2)
a = a.reshape(2, 4)
print('\nArray\n', a)

print('\nIterating')
for x in np.nditer(a):
    print(x)

b = a.T

print('\nTranspose\n', b)
print('\nIterating')
for x in np.nditer(b):
    print(x)

print('\nSorted in C-style\n')
c = b.copy(order='C')
print(c)
print('\nIterating')
for x in np.nditer(c):
    print(x)
print('\nSorted in F-style\n')
c = b.copy(order='F')
print(c)
print('\nIterating')
for x in np.nditer(c):
    print(x)

