import numpy as np

a = np.arange(1, 17)
print('\nArray\n', a)

print('\nSplit in 4 equal size\n', np.split(a, 4))

print('\nSplit [4,7]\n', np.split(a, [4, 7]))


b = a.reshape(4,4)
print('\nArray\n',b)
print('\nHorizontal Split\n', np.hsplit(b, 2))
print('\nVertical Split\n', np.vsplit(b, 2))