import numpy as np

a = np.arange(10)
print(a)  # [0 1 2 3 4 5 6 7 8 9]
# slice(start, stop, step)
s = slice(2, 7, 2)
print(a[s])  # [2 4 6]

# start:stop:step
s = a[2:7:2]
print(s)  # [2 4 6]

# slice from index
print(a[5:])  # [5 6 7 8 9]

# slice between indexes
print(a[2:5]) # [2 3 4]

