import numpy as np

""" Saving as npy file """

# # Creating array
# a = np.arange(1, 10).reshape(3, 3)
# # Saving to File
# np.save('toFile',a)


# # Load file
# b = np.load('toFile.npy')
# print(b)


""" Save as txt file """
# # Creating array
# a = np.arange(1, 10).reshape(3, 3)
# # Saving to File
# np.savetxt('toFile.txt',a)


# Load file
b = np.loadtxt('toFile.txt')
print(b)

