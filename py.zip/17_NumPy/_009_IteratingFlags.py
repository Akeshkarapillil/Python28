import numpy as np

a = np.arange(2, 18, 2)
a = a.reshape(2, 4)
print('\nArray\n', a)

# op_flag = readonly(default), readwrite, writeonly
for x in np.nditer(a, op_flags=['readwrite']):
    x[...] = 2 * x
print('\nModified array:\n', a)

print('\nexternal_loop, order "F"\n')
for x in np.nditer(a, flags=['external_loop'], order='F'):
    print(x)

print('\nBroadcasting Iteration\n')
b = np.array([11, 22, 33, 44])
print('\nArray ii\n', b)
print('\nModified\n')
for x, y in np.nditer([a, b]):
    print('%d:%d' % (x, y))
