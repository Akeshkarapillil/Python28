import numpy as np

a = np.array([1, 2, 3, 4, 5, 6])
print(a, a.shape, '\n', '.'*20)
# a.shape = (2, 3)
a = a.reshape(3, 2)
print(a, a.shape, '\n', '.'*20)

b = np.arange(9)
print(b, b.shape, '\n', '.'*20)
b.shape = (3, 3)
print(b, b.shape, '\n', '.'*20)
print('default int size: ',b.itemsize)

c = np.array([1,2,3],dtype = np.int8)
print('int8 size: ',c.itemsize)
c = np.array([1,2,3],dtype = np.int16)
print('int16 size: ',c.itemsize)
c = np.array([1,2,3],dtype = np.int32)
print('int32 size: ',c.itemsize)
c = np.array([1,2,3],dtype = np.int64)
print('int64 size: ',c.itemsize)