import numpy as np

print('\nBinary equivalent of 10 and 18\n')
a, b = 10, 18
print(bin(10), bin(18))
print('\nBitwise AND of 10, 18\n')
c = np.bitwise_and(10, 18)
print(c)
print('\nbinary of %d\n' % (c), bin(c))
print('\nBitwise OR of 10, 18\n')
c = np.bitwise_or(10, 18)
print(c)
print('\nbinary of %d\n' % (c), bin(c))
d = np.invert(np.array([13], dtype=np.uint8))
d = int(d)
print('\nInvert of 13 unit8\n', d)
print('\nbinary of 13\n', np.binary_repr(13, width=8))
print('\nbinary of 13 invert %s \n' % d, np.binary_repr(d, width=8))

e = int(np.left_shift(13, 2))
print('\n13 after two left shift %d and binary is\n' %
      e, np.binary_repr(e, width=8))
e = int(np.right_shift(13, 2))
print('\n13 after two right shift %d and binary is\n' %
      e, np.binary_repr(e, width=8))
