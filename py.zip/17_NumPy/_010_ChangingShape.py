import numpy as np

a = np.arange(10, 22, 2)
print('array\n', a)
a = a.reshape(2, 3)
print('After reshape\n', a)

x = a.flatten()
print('\nFlatten \n', x)
x *= 2
print('\nafter change in flatten() object\n',a)

# same as flatten() but same object is copying 
# so any change in copied object will reflect on actual
y = a.ravel()
print('\nravel\n', y)  
y*=2
print('\nafter change in ravel() object\n',a)
