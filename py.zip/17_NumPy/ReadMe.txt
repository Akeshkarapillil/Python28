NumPy stands for numeric python which is a python package for the computation and processing of the multidimensional and single dimensional array elements.

Windows
=======
c:\> pip install numpy

Ubuntu
======
$ sudo apt-get install python-numpy
$ python-scipy python-matplotlibipythonipythonnotebook python-pandas
$ python-sympy python-nose

Redhat
======
$ sudo yum install numpyscipy python-matplotlibipython
$ python-pandas sympy python-nose atlas-devel

