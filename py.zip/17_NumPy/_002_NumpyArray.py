import numpy as np

# generates random numbers,ie. not initialized
x = np.empty([3, 2], dtype=int)
print(x)
print('='*20)

# Initializes with zeros
x = np.zeros([3, 2], dtype=int)
print(x)
print('='*20)

# Initializes with ones
x = np.ones([3, 2], dtype=int)
print(x)
print('='*20)

# asarray()
x = [[1, 2, 3], [4, 5, 6]]
a = np.asarray(x)
print(a, a.shape)
print('='*20)

# can use tuple also
x = ((1, 2, 3), (4, 5, 6))
a = np.asarray(x)
print(a, a.shape)
print('='*20)

# frombuffer
# buffer as one-dimensional array.
# Any object that exposes the buffer interface
# is used as parameter to return an ndarray
s = b'Hello World!'  # converting to binary
# After S, Number should be the multiple of given buffer eg. S1,S2 etc.
a = np.frombuffer(s, dtype='S2')
print(a)
print('='*20)

lst = range(5)
# print(lst)
it = iter(lst)
# print(it)
# ndarray from iter object
x = np.fromiter(it, dtype=int)
print(x)
print('='*20)
