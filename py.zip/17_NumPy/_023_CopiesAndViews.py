import numpy as np

a = np.arange(1, 7)
print("\n Array \n", a)
b = a
print("\n b = a, ie. b =  \n", b)
print("\n id(a) \n", id(a))
print("\n id(b) \n", id(b))
b.shape = 3, 2
print("\n b.shape = 3,2 ie. b =  \n", b)
print("\n a is also changed. ie. a = \n", a)

print("\n\n", "*" * 20, "\nView\n", "*" * 20, "\n")
a = np.arange(1, 7)
b = a.view()
print("\n b = a.view(), ie. b =  \n", b)
print("\n id(a) \n", id(a))
print("\n id(b) \n", id(b))
b.shape = 3, 2
print("\n b.shape = 3,2 ie. b =  \n", b)
print("\n a is not changed. ie. a = \n", a)

print("\n\n", "*" * 20,
      "\n slice creates a view (b = a[:]) \n", "*" * 20, "\n")
a = np.arange(1, 7)
b = a[:]
print("a = ", a, "id(a) = ", id(a))
print("b = ", b, "id(b) = ", id(b))

print("\n\n", "*" * 20, "\n copy() not shares the orginal array \n", "*" * 20, "\n")
a = np.arange(1, 10).reshape(3, 3)
b = a.copy()
print("id(a) = ", id(a))
print("id(b) = ", id(b))
