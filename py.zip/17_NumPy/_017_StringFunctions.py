import numpy as np

print("\n char.add(['hello'],[' xyz'])", np.char.add(['hello'], [' xyz']))
print("\n char.add(['hello','hi'],[' world',' how are you ?'])",
      np.char.add(['hello', 'hi'], [' world', ' how are you ?']))

print('\n char.multiply("Hello ",3)', np.char.multiply('Hello ', 3))

print('\n char.center("Hello World !!!", 40, fillchar="*")\n',
      np.char.center("Hello World !!!", 40, fillchar="*"))

print("\n char.capitalize('hello world !!!')",
      np.char.capitalize('hello world !!!'))
print("\n char.title('hello world !!!')",
      np.char.title('hello world !!!'))
print("\n char.lower('hello world !!!')",
      np.char.lower('hello world !!!'))
print("\n char.upper('hello world !!!')",
      np.char.upper('hello world !!!'))
print("\n char.split('hello\\nworld\\n!!!', sep=' ')",
      np.char.split('hello\nworld\n!!!', sep=' '))
print("\n char.strip('arunima rama', 'a')",
      np.char.strip('arunima rama', 'a'))
print("\n char.strip(['arunima', 'aleena', 'jeeva'], 'a')",
      np.char.strip(['arunima', 'aleena', 'jeeva'], 'a'))
print("\n char.join(':','dmy')",
      np.char.join(':', 'dmy'))
print("\n char.join([':','-'],['dmy','ymd'])",
      np.char.join([':', '-'], ['dmy', 'ymd']))
print("\n char.replace('he is a MLA', 'is', 'was') ",
      np.char.replace('he is a MLA', 'is', 'was'))
a = np.char.encode('Hello World !!!', 'cp500')
print("\n Encoded: ", a)
print("\n Decoded: ", np.char.decode(a, 'cp500'))
