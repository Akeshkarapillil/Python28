import numpy as np
a = np.array([[11, 22, 33], [44, 55, 66], [77, 88, 99]])
print('Full List')
print(a)
print('.'*30)

print('from 2nd row onwards')
print(a[1:]) # from 2nd row onwards
print('.'*30)

print('Till 2nd row')
print(a[:2]) # Till 2nd row
print('.'*30)

print('Only 2nd row (1 to 2 row)')
print(a[1:2]) # Only 2nd row (1 to 2 row)
print('.'*30)

print('only 2nd row')
print(a[1,...]) # only 2nd row
print('.'*30)

print('2nd row onwards')
print(a[1:,...]) # 2nd row onwards
print('.'*30)

print('only 2nd Column')
print(a[...,1]) # only 2nd Column
print('.'*30)

print('2nd column onwards')
print(a[...,1:]) # 2nd column onwards
print('.'*30)