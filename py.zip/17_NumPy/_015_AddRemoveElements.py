import numpy as np

a = np.arange(1, 7)
print('\nArray\n', a)
a = np.resize(a, (2, 3))
print('\nAfter resize:\n', a)


print('\nAfter append(a, [11, 22, 33])\n', np.append(a, [11, 22, 33]))
print('\nAfter append(a, [[11, 22, 33]],axis=0)\n',
      np.append(a, [[11, 22, 33]], axis=0))
print('\nAfter append(a, [[11, 22, 33], [44, 55, 66]], axis=1)\n',
      np.append(a, [[11, 22, 33], [44, 55, 66]], axis=1))


print('\n insert(a, 2, [111, 222, 333])\n', np.insert(a, 2, [111, 222, 333]))
print('\n insert(a, 2, [111, 222, 333], axis=0)\n',
      np.insert(a, 2, [111, 222, 333], axis=0))
print('\n insert(a, 2, [111, 222], axis=1)\n',
      np.insert(a, 2, [111, 222], axis=1))
print('\n insert(a, 2, [1111], axis=0)\n',
      np.insert(a, 2, [1111], axis=0))


print('\ndelete(a,4)\n', np.delete(a, 4))
print('\ndelete(a, 1, axis=1)\n', np.delete(a, 1, axis=1))
print('\ndelete(a, np.s_[::2])\n', np.delete(a, np.s_[::2]))


a = np.array([4, 8, 5, 6, 4, 7, 5])
print('\nArray\n', a)
print('\nunique(a)\n', np.unique(a))
print('\nunique(a,return_index=True)\n', np.unique(a, return_index=True))
print('\nunique(a,return_inverse=True)\n', np.unique(a, return_inverse=True))
print('\nunique(a,return_counts=True)\n', np.unique(a, return_counts=True))
