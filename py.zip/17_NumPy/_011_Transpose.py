import numpy as np

a = np.arange(10, 22, 2)
a = a.reshape(2, 3)
print('array\n', a)

# x = a.transpose()
x = a.T  # same as transpose()
print('\nAfter Transpose\n', x)

r = np.rollaxis(a, 1)
print('\nrollaxis()\n', r)

b = np.arange(1, 28, 1)
b = b.reshape(3, 3, 3)
print('\n3 X 3 X 3\n', b)
r1 = np.rollaxis(b,1)
print('\nrollaxis(b,1)\n',r1)
r1 = np.rollaxis(b, 2)
print('\nrollaxis(b,2)\n', r1)

a = np.arange(1, 25).reshape(2, 3, 4)
print('\nOrginal Array: \n', a)
b = np.swapaxes(a, 0, 1)
print('\nswapaxes(a, 0, 1)\n', b)
b = np.swapaxes(a, 1, 2)
print('\nswapaxes(a, 0, 2)\n', b)
