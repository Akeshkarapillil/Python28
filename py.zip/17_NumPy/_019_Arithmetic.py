import numpy as np

a = np.arange(1, 10).reshape(3, 3)
b = np.array([10, 10, 10])
print("\n Array I \n", a)
print("\n Array II \n", b)

print("\n b + a \n", np.add(b, a))
print("\n b - a \n", np.subtract(b, a))
print("\n b X a \n", np.multiply(b, a))
print("\n b / a \n", np.divide(b, a))
print("\n mod() b % a \n", np.mod(b, a))
print("\n remainder() b % a \n", np.remainder(b, a))

print("\n power(a,2) \n", np.power(a, 2))

c = np.array([0.25, 0.5, 0.75, 1, 4, 5, 10])
print("\n Array \n", c)
print("\n Reciprocal (ie. 1/number) \n", np.reciprocal(c))

d = np.array([-1.2j, 0.2j, 11, 1+2j])
print("\nArray\n", d)
#  returns the real part of the complex data type argument.
print("\n real(a) \n", np.real(d))
# returns the imaginary part of the complex data type argument.
print("\n imag(a) \n", np.imag(d))
# returns the complex conjugate, which is obtained by changing
# the sign of the imaginary part.
print("\n conj(a) \n", np.conj(d))
# returns the angle of the complex argument.
print("\n angle(a) \n", np.angle(d))
# The function has degree parameter.
# If true, the angle in the degree is returned,
# otherwise the angle is in radians.
print("\n angle(a, deg = True) \n", np.angle(d, deg=True))
