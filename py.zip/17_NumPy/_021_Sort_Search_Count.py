import numpy as np

# sort(a, axis, kind, order)
# a -> Array to be sorted,
# axis -> along which the array is to be sorted.
# If none, the array is flattened, sorting on the last axis,
# kind -> Default is quicksort,
# order -> If the array contains fields, the order of fields to be sorted

a = np.array([[2, 5], [8, 3]])
print("\n Array \n", a)
print("\n sort(a) \n", np.sort(a))
print("\n sort(a, axis = 0) \n", np.sort(a, axis=0))

# Order parameter in sort function
dt = np.dtype([('name', 'S10'), ('age', int)])
a = np.array([("raju", 21), ("anil", 25),
              ("ravi", 17), ("amar", 27)], dtype=dt)
print('\n Our array is: \n', a)
print('\n Order by name: \n', np.sort(a, order='name'))

# argsort() function performs an indirect sort on input array,
# along the given axis and using a specified kind of sort
# to return the array of indices of data. This indices array
# is used to construct the sorted array.
x = np.array([33, 15, 27])
print("\nArray\n", x)
y = np.argsort(x)
print("\n argsort(x) \n", y)
print("\n reconstruct the orginal array \n", x[y])
print("\n reconstruct the orginal array using loop \n")
for i in y:
    print(x[i])

# lexsort() performs an indirect sort using a sequence of keys.
# The keys can be seen as a column in a spreadsheet.
# The function returns an array of indices, using which
# the sorted data can be obtained. Note, that the last key
# happens to be the primary key of sort.
names = ('Neena', 'Anil', 'Shyam', 'Ammu', 'Shyama')
places = ('EKM', 'TVM', 'KTM', 'EKM', 'TVM')
salary = (50000, 15000, 18000, 12000, 16000)

ind = np.lexsort((names, places, salary))
print("\n lexsort() \n", ind)
print("\n Sorted Data \n")
print([names[i] + ", " + places[i] + ", " + str(salary[i]) for i in ind])

# argmax(), argmin()
# return the indices of maximum and minimum elements respectively along
# the given axis.
a = np.array(
    [
        [30, 40, 70],
        [80, 0, 10],
        [50, 90, 0]
    ]
)
print("\nArray\n", a)
print("\n argmax(a) \n", np.argmax(a))
print("\n a.flatten() \n", a.flatten())
print("\n argmax(a, axis=0) \n", np.argmax(a, axis=0))
print("\n argmax(a, axis=1) \n", np.argmax(a, axis=1))
print("\n argmin(a) \n", np.argmin(a))
print("\n argmin(a, axis=0) \n", np.argmin(a, axis=0))
print("\n argmin(a, axis=1) \n", np.argmin(a, axis=1))

# numpy.nonzero() function returns the indices of
# non-zero elements in the input array.
nz = np.nonzero(a)
print("\n nonzero(a) \n", nz)
print("\n Elements: \n", a[nz])
# numpy.where() function returns the indices of elements in an
# input array where the given condition is satisfied.
gt = np.where(a > 50)
print("\n where(a > 50) \n", gt)
print("\n Elements: \n", a[gt])

# numpy.extract() function returns the elements satisfying any condition.
cond = np.mod(a, 3) == 0
print("\ncondition : mod(a,3) \n", cond)
print("\n extract(cond,a) \n", np.extract(cond, a))
