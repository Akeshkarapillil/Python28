import numpy as np

# Integer indexing
x = np.array([[11, 22, 33], [44, 55, 66], [77, 88, 99]])
print("All elements")
print(x)

print("\n(0,0) element")
y = x[[0], [0]]
print(y)

print("\n(0,0), (1,1), (2,2) elements")
y = x[[0, 1, 2], [0, 1, 2]]
print(y)

print('\n (0,0), (0,2) \n (2,0),(2,2) \n (1,1),(0,1)')
r = np.array([[0, 0], [2, 2], [1, 0]])
c = np.array([[0, 2], [0, 2], [1, 1]])
y = x[r, c]
print(y)

print('\n (0,0),(1,0),(2,0) \n (0,2),(1,2),(2,2)')
r = np.array([[0, 1, 2], [0, 1, 2]])
c = np.array([[0, 0, 0], [2, 2, 2]])
y = x[r, c]
print(y)

print('\n2nd to 3rd row & 2nd to 3rd column')
y = x[1:3, 1:3]
print(y)

print('\n2nd to 3rd row & 1st and 3rd column using advanced indexing')
y = x[1:3, [0, 2]]
print(y)

# Boolean Indexing
print('\nelements > 50')
y = x[x > 50]
print(y)

print('\nelements < 50 using negation')
y = x[~(x > 50)]
print(y)

a = np.array([1,np.nan,4,np.nan,7])
print('\nElements\n',a)
print('\n Only Numbers\n',a[~np.isnan(a)])

a = np.array([11,2+4j,55,4.1+7j])
print('\nElements\n',a)
print('\nOnly Complex Numbers\n', a[np.iscomplex(a)])