import numpy as np

a = np.arange(1, 5).reshape(2, 2)
b = np.arange(11, 15).reshape(2, 2)

print('\nArray a\n', a)
print('\nArray b\n', b)
print('\nConcatenated default\n', np.concatenate((a, b)))
print('\nConcatenated axis 1\n', np.concatenate((a, b), axis=1))
print('\nStack default\n', np.stack((a, b)))
print('\nStack axis 1\n', np.stack((a, b), 1))
print('\nHorizontal Stack \n', np.hstack((a, b)))
print('\nVertical Stack \n', np.vstack((a, b)))