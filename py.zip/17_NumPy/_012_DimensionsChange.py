import numpy as np
# Broadcast
x = np.arange(1, 7).reshape(2, 3)
y = np.arange(11, 14)

print('\nArray I\n', x)
print('\nArray II\n', y)
b = np.broadcast(x, y)
# r, c = b.iters
print('\nbroadcast from I to II\n')
for m in b:
    print(m)

print('\nI + II = \n', x+y)

# Broadcast_to
b = np.broadcast_to(y, (3, 3))
print('\nArray II broadcast_to(y,(3,3))\n', b)

# expand_dims
a = np.arange(1, 5).reshape(2, 2)
print('\nArray III\n', a)
print('\nShape\n', a.shape)
b = np.expand_dims(a, axis=0)
print('\nnp.expand_dims(a, axis=0)\n', b)
print('\nShape\n', b.shape)
print('\nndim\n',b.ndim)

c = np.expand_dims(a, axis=1)
print('\nnp.expand_dims(a, axis=1)\n', c)
print('\nShape\n', c.shape)
print('\nndim\n',c.ndim)

# squeeze
a = np.arange(1,10).reshape(1,3,3)
print('\nArray\n',a)
d = np.squeeze(a)
print('\nAfter squeeze\n',d)