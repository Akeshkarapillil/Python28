import numpy as np
import numpy.matlib as ml


a = np.array([[1, 2], [3, 4]])
b = np.array([[11, 12], [13, 14]])

print("\n Array I \n", a)
print("\n Array II \n", b)

# numpy.dot() function returns the dot product of two arrays
# [[1*11+2*13, 1*12+2*14],[3*11+4*13, 3*12+4*14]]
print("\n dot(a, b) \n", np.dot(a, b))


# numpy.vdot() function returns the dot product of the two vectors.
# 1*11 + 2*12 + 3*13 + 4*14 = 130
print("\n vdot(a, b) \n", np.vdot(a, b))

# numpy.inner() function returns the inner product
# of vectors for 1-D arrays. For higher dimensions,
# it returns the sum product over the last axes.
# [[1*11+2*12, 1*13+2*14], [3*11+4*12, 3*13+4*14]]
print("\n inner(a,b) \n", np.inner(a, b))

# numpy.matmul() function returns the matrix product of two arrays.
print("\n matmul(a, b) \n", np.matmul(a, b))

# Determinant is a very useful value in linear algebra.
# It calculated from the diagonal elements of a square matrix.
# For a 2x2 matrix, it is simply the subtraction of the product
# of the top left and bottom right element from the product of other two.
print("\n np.linalg.det(a) \n", np.linalg.det(a))

# numpy.linalg.inv() function to calculate the inverse of a matrix.
# The inverse of a matrix is such that if it is multiplied by
# the original matrix, it results in identity matrix.
print("\n inv(a) \n", np.linalg.inv(a))
