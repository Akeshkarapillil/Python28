import numpy as np
a = np.array([[3, 7, 5], [8, 4, 3], [2, 4, 9]])

# min, max
print("\n array \n", a)
print("\n amin(a) \n", np.amin(a))
print("\n amin(a,axis=1) \n", np.amin(a, axis=1))
print("\n amin(a,axis=0) \n", np.amin(a, axis=0))
print("\n amax(a) \n", np.amax(a))
print("\n amax(a,axis=1) \n", np.amax(a, axis=1))
print("\n amax(a,axis=0) \n", np.amax(a, axis=0))

# ptp() returns the range (maximum-minimum) of values along an axis.
print("\n ptp(a) \n", np.ptp(a))
print("\n ptp(a, axis=1) \n", np.ptp(a, axis=1))
print("\n ptp(a, axis=0) \n", np.ptp(a, axis=0))

# percentile(a, q, axis) (or a centile) is a measure used in statistics
# indicating the value below which a given percentage of observations
# in a group of observations fall.
# a -> Input array, q -> The percentile to compute must be between 0-100,
# axis -> The axis along which the percentile is to be calculated
a = np.arange(10, 100, 10).reshape(3, 3)
print("\n array \n", a)
print("\n percentile(a, 50) \n", np.percentile(a, 50))
print("\n percentile(a, 50, axis=1) \n", np.percentile(a, 50, axis=1))
print("\n percentile(a, 50, axis=0) \n", np.percentile(a, 50, axis=0))

# median() is defined as the value separating the higher half of
# a data sample from the lower half.
print("\n median(a, 50) \n", np.median(a))
print("\n median(a, axis=1) \n", np.median(a, axis=1))
print("\n median(a, axis=0) \n", np.median(a, axis=0))

# mean() is the sum of elements along an axis divided by the number of elements.
print("\n mean(a, 50) \n", np.mean(a))
print("\n mean(a, axis=1) \n", np.mean(a, axis=1))
print("\n mean(a, axis=0) \n", np.mean(a, axis=0))

# average
print("\n average(a) \n", np.average(a))
print("\n average(a, axis=1) \n", np.average(a, axis=1))
print("\n average(a, axis=0) \n", np.average(a, axis=0))

# Standard Deviation is the square root of the
# average of squared deviations from mean.
# std = sqrt(mean(abs(x - x.mean())**2))
print("\n std([1,2,3,4]) \n",np.std([1,2,3,4]))
