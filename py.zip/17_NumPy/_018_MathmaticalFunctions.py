import numpy as np

a = np.array([0, 30, 45, 60, 90])
print("\nAngles\n", a)
# convert into radians by multiplying with pi/180
sin = np.sin(a*np.pi/180)
inv = np.arcsin(sin)
print("\nSin of Angles\n", sin)
print("\nSin inverse of Angles in radians\n", inv)
print("\nConverting to degrees\n", np.degrees(inv))

cos = np.cos(a*np.pi/180)
inv = np.arccos(cos)
print("\nCosin of Angles\n", cos)
print("\nCosin inverse of Angles in radians\n", inv)
print("\nConverting to degrees\n", np.degrees(inv))

tan = np.tan(a*np.pi/180)
inv = np.arctan(tan)
print("\nTangent of Angles\n", tan)
print("\nTangent inverse of Angles in radians\n", inv)
print("\nConverting to degrees\n", np.degrees(inv))

a = np.array([1.0, 5.55, .0045, 123, 25.678])
print("\n Array \n", a)
print("\n around(a) \n", np.around(a))
print("\n around(a, decimals = 1) \n", np.around(a, decimals=1))
print("\n around(a, decimals = -1) \n", np.around(a, decimals=-1))

print("\n floor(a) \n", np.floor(a))
print("\n ceil(a) \n", np.ceil(a))
