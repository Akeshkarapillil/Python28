from tkinter import Tk, Button, Frame


class HomePage:
    def __init__(self, top):
        top.geometry("280x150")
        top.title("Home")
        Button(top, text="Login", font=(
            'Arial Rounded MT', 15), bd=5, command=self.__goLogin).place(x=50, y=50)
        Button(top, text="Register", font=(
            'Arial Rounded MT', 15), bd=5, command=self.__goReg).place(x=150, y=50)
        self.top = top
        Frame(top).pack()

    def __goLogin(self):
        from _010_Login import LoginPage
        from _010_ClearForm import ClearMe
        ClearMe(self.top)
        LoginPage(self.top)

    def __goReg(self):
        from _010_Register import RegisterPage
        from _010_ClearForm import ClearMe
        ClearMe(self.top)
        RegisterPage(self.top)

# top = Tk()
# HomePage(top)
# top.mainloop()
