from tkinter import Tk, Button, Frame, Label, Entry


class LoginPage:
    def __init__(self, top):
        top.geometry("400x220")
        top.title("Login")
        Label(top, text="User Name", font=1).place(x=50, y=50)
        Label(top, text="Password", font=1).place(x=50, y=100)
        self.uname = Entry(top, bd=5, font=1)
        self.uname.place(x=150, y=50)
        self.pwd = Entry(top, bd=5, show="*", font=1)
        self.pwd.place(x=150, y=100)
        Button(top, text="Home", bd=5, font=1, command = self.__goHome).place(x=200, y=150)
        Button(top, text="Login", bd=5, font=1).place(x=280, y=150)
        self.top = top
        Frame(top).pack()

    def __goHome(self):
        from _010_Home import HomePage
        from _010_ClearForm import ClearMe
        ClearMe(self.top)
        HomePage(self.top)

# top = Tk()
# LoginPage(top)
# top.mainloop()
