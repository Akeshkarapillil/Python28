from tkinter import Tk
from _010_Home import HomePage

top = Tk()
HomePage(top)
top.mainloop()
