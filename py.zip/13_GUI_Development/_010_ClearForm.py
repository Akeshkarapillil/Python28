def ClearMe(win):
    w = []
    for x in win.children.values():
        w.append(x)
    for x in w:
        x.destroy()
