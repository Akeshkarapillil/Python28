from tkinter import Tk, Entry, Label, Button,INSERT, StringVar
from tkinter.scrolledtext import ScrolledText

t = Tk()
t.geometry('300x400')
t.title('Chat Engine')

def chat():
    s = msg_from.get()
    msg.set('')
    msg_to.config(state = 'normal')
    msg_to.insert(INSERT,s+"\n")
    msg_to.config(state = 'disabled')

def txtEve(e):
    chat()

Label(t, text="Chat Engine").place(x=10, y=10)
msg_to = ScrolledText(t,height='10',width='30', state='disabled')
msg_to.place(x=10, y=50)
msg = StringVar()
msg_from = Entry(t,textvariable = msg)
msg_from.focus_set()
msg_from.bind('<Return>',txtEve)
msg_from.place(x=10, y=240, width='220', height='40')
Button(t,text = 'Send',height='2',command = chat).place(x='240',y = '240')

t.mainloop()
