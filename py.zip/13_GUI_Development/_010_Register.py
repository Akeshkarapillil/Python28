from tkinter import Tk, Button, Frame, Label, Entry, Radiobutton, StringVar
from tkinter.ttk import Combobox


class RegisterPage:
    def __init__(self, top):
        top.geometry("400x320")
        top.title("Register")
        Label(top, text="User Name", font=1).place(x=50, y=50)
        Label(top, text="Password", font=1).place(x=50, y=100)
        self.uname = Entry(top, bd=5, font=1)
        self.uname.place(x=150, y=50)
        self.pwd = Entry(top, bd=5, font=1, show="?")
        self.pwd.place(x=150, y=100)
        self.gender = StringVar()
        Label(top, text="Gender", font=1).place(x=50, y=150)
        Radiobutton(top, text="Male", value='M',
                    variable=self.gender, font=1).place(x=150, y=150)
        Radiobutton(top, text="Female", value='F',
                    variable=self.gender, font=1).place(x=230, y=150)
        self.placeVal = StringVar()
        Label(top, text="Place", font=1).place(x=50, y=200)
        self.place = Combobox(top, textvariable=self.placeVal, width=28)
        self.place['values'] = ('India', 'UAE', 'USA', 'UK', 'Other')
        self.place.place(x=150, y=200)
        Button(top, text="Home", bd=5, font=1,
               command=self.__goHome).place(x=210, y=250)
        Button(top, text="Login", bd=5, font=1).place(x=280, y=250)
        self.top = top
        Frame(top).pack()

    def __goHome(self):
        from _010_Home import HomePage
        from _010_ClearForm import ClearMe
        ClearMe(self.top)
        HomePage(self.top)

# top = Tk()
# f = RegisterPage(top)
# f.gender.set('M')
# top.mainloop()
