'''
searches the string for a match, and returns a Match object 
if there is a match.If there is more than one match, 
only the first occurrence of the match will be returned
'''

import re
txt = "rain rain go away"
x = re.search("^rain",txt) #Start with "rain"
print(x)
x = re.search("away$",txt) # ends with "away"
print(x)
x = re.search("[b-j]",txt) # contains "b" to "j"
print(x)
x = re.search("[^b-j]",txt) # not contains "b" to "j"
print(x)