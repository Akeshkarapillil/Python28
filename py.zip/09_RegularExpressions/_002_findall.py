'''
    function returns a list containing all matches
'''
import re
txt = "rain rain go away"
x = re.findall("^rain",txt) #Start with "rain"
print(x)
x = re.findall("away$",txt) # ends with "away"
print(x)
x = re.findall("[b-j]",txt) # contains "b" to "j"
print(x)
x = re.findall("[^b-j]",txt) # not contains "b" to "j"
print(x)