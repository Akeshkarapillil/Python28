'''
    function returns a list where the string has been split at each match
'''

import re
txt = "rain rain go away"
x = re.split("^rain",txt) #Start with "rain"
print(x)
x = re.split("away$",txt) # ends with "away"
print(x)
x = re.split("[b-j]",txt) # contains "b" to "j"
print(x)
x = re.split("[^b-j]",txt) # not contains "b" to "j"
print(x)