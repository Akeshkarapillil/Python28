'''
    function replaces the matches with the text of your choice
'''
import re
txt = "rain rain go away"
x = re.sub("^rain", "thunder", txt)  # Start with "rain"
print(x)
x = re.sub("away$", "far", txt)  # ends with "away"
print(x)
x = re.sub("[b-j]", "*", txt)  # contains "b" to "j"
print(x)
x = re.sub("[^b-j]", "#", txt)  # not contains "b" to "j"
print(x)

# Replace the first 1 occurrences
x = re.sub("rain", "thunder", txt, 1)
print(x)
# Replace the all occurrences
x = re.sub("rain", "thunder", txt)
print(x)
