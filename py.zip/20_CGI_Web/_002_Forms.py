#!python
import cgi
form = cgi.FieldStorage()
name = form.getvalue('name','unknown Name')
place = form.getvalue('place','unknown Place')
print('Content-type: text/html\n\n')
print('<html><head>')
print('<h1>Welcome %s from %s</h1>' % (name, place))
print('</head></html>')
