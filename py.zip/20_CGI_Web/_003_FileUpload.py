#!python
import cgi
import os
import cgitb
# enabling debug mode
cgitb.enable()

# Windows needs stdio set for binary mode.
try:
    import msvcrt
    # stdin = 0
    msvcrt.setmode(0, os.O_BINARY)
    # stdout = 0
    msvcrt.setmode(1, os.O_BINARY)
except ImportError:
    pass

form = cgi.FieldStorage()
file = form['file']
des = form.getvalue('des', None)

if file.filename:
    fn = os.path.basename(file.filename)
    open('uploads/' + fn, 'wb').write(file.file.read())
    msg = fn + ' uploaded successfully !!!'
else:
    msg = 'No file uploaded ?'

cont = '''Content-Type: text/html\n
    <html><body>
        <h1> %s </h1>
        <h4> %s </h4>
    </body></html>
'''
print(cont % (msg, des))
