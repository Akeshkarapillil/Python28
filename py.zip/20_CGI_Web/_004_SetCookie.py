#!python
import time
t = time.time() + 60 * 60

print("Set-Cookie:lang=Python; Expires=" +
      time.asctime(time.localtime(t)) + "; Path=/py;")
print("Content-Type: text/html\n\n")
s = '''
    <html>
        <body>
            <h1> Server time is %s </h1>
        </body>
    </html>
'''
print(s % (str(time.asctime(time.localtime()))))
