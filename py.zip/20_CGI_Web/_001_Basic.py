#!python
print("Content-type: text/html\n\n")
print("<html><head>")
print("</head><body>")
print("<h1>Hello.</h1>")
print("</body></html>")
