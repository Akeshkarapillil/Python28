#!python

import time, http.cookies as h

x = h.SimpleCookie()

x['lang'] = 'Python'
x['lastvisit'] = str(time.time())
x['lang']['Expires'] = time.asctime()
x['lang']['Path'] = "/py"
x['lastvisit']['Expires'] = time.asctime()

print(x)
print("Content-Type: text/html\n")
s = '''
    <html>
        <body>
            <h1> Server time is %s </h1>
        </body>
    </html>
'''
print(s % (str(time.asctime(time.localtime()))))
