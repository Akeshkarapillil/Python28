class Employee:
	empCnt = 0
	
	def __init__(self,name):
		Employee.empCnt += 1
		self.id = Employee.empCnt
		self.name = name

	def dispCount(self):
		print('Total Employee %d' % Employee.empCnt)

	def dispEmp(self):
		print ('Id : ', self.id, ', Name : ',self.name)

e1 = Employee('Anoop')
e2 = Employee('Ashok')

e1.dispEmp()
e2.dispEmp()
#e1.dispCount()
print('Total Employee %d' % Employee.empCnt)
