class Employee:
	empCnt = 0
	
	def __init__(self,name):
		Employee.empCnt += 1
		self.id = Employee.empCnt
		self.name = name

	
		
	def dispCount(self):
		print('Total Employee %d' % Employee.empCnt)

	def dispEmp(self):
		print ('Id : ', self.id, ', Name : ',self.name)

e1 = Employee('Anoop')
e2 = Employee('Ashok')
setattr(e1,'salary',12000)
e1.age = 25

print('Employee 1 Contains salary:',hasattr(e1,'salary'))
print('Employee 2 Contains salary:',hasattr(e2,'salary'))

e1.dispEmp()
e2.dispEmp()
print('Salary : ',getattr(e1,'salary'))
print('Age : ',e1.age)
delattr(e1,'salary')
print('After deletion Employee 1 Contains salary:',hasattr(e1,'salary'))
#e1.dispCount()
print('Total Employee %d' % Employee.empCnt)
