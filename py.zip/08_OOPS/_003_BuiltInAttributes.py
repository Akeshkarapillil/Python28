class Address:
	place = 'Unknown'

class Emp(Address):
	'''
	Test
	Sample Employee class
	'''
	def disp(s):
		print('Welcome',s)
	


print('\n Dictionary containing the class''s namespace : ',Emp.__dict__)
print('\n Class documentation string : ',Emp.__doc__)
print('\n Emp.__name__ : ',Emp.__name__)
print('\n module name in which the class is defined : ',Emp.__module__)
print('\n base class list : ',Emp.__bases__)