class A:
	def dispA(self):
		print('dispA()');

class B:
	def dispB(self):
		print('dispB()');

class C (A,B):
	def dispC(self):
		print('dispC()');

x = C()
x.dispA()
x.dispB()
x.dispC()