class Details:
	x = 100
	__y = 200 # hidden value
	def disp1(self):
		print('disp1()')
	def __disp2(self): # hidden function
		print('disp2()')

print('x = ',Details.x)
# print('y = ',Details.__y) # will create error

m = Details()
m.disp1()
# m.__disp2() # will create error