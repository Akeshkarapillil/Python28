class A:
	def dispA(self):
		print('dispA()');

class B(A):
	def dispA(self):
		print('dispA() from B');
	def dispB(self):
		print('dispB()');

class C(A):
	def dispA(self):
		print('dispA() from C');
	def dispC(self):
		print('dispC()');

class D(B,C):
	def dispD(self):
		print('dispD()');

x = D()
x.dispA()
x.dispB()
x.dispC()
x.dispD()