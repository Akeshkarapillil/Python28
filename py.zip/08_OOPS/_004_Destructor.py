class Test:
	def __init__(self,x):
		self.x = x
		print('Creating Test object with x = ',self.x)
	def __del__(self):
		print('Deleting Test object with x = ',self.x)


t1 = Test(1)
del t1
t2 = Test(2)
t3 = Test(3)
