try:
	a = int(input('Enter Ist No: '))
	b = int(input('Enter Ist No: '))
	c = a/b
	print('Result = ',c)
except (ValueError,ZeroDivisionError) as e:
	print('Check the given values !!!\n',e)
	print('Exception name is: ',type(e).__name__)
except:
	print('Pgm interrupted...')
print('pgm finished..!	')

# ValueError -> Error in no. format
#ZeroDivisionError