try:
	a = int(input('Enter Ist No: '))
	b = int(input('Enter Ist No: '))
	c = a/b
	print('Result = ',c)
finally:
	print('finally block...')
print('pgm finished..!	')
