try:
	a = int(input('Enter Ist No: '))
	b = int(input('Enter Ist No: '))
	c = a/b
	print('Result = ',c)
except ValueError:
	print('Only integers allowed !!!')
except ZeroDivisionError:
	print('2nd no. cann''t be zero !!!')
except:
	print('Pgm interrupted..')
print('pgm finished..!	')

# ValueError -> Error in no. format
#ZeroDivisionError