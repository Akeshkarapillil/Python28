def check(n):
	if n<0 : raise Exception
	print('Accepted: ',n)

try:
	a = int(input('Enter Ist No: '))
	check(a)
except ValueError as e:
	print('Only integers allowed !!!\n',e)
except Exception as e:
	print('-ve values not allowed\n',e)
except:
	print('Pgm interrupted..')
print('pgm finished..!	')