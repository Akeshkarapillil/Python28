class NegVal(Exception):
	def __init__(self,value):
		self.value = value
	def __str__(self):
		return self.value

def check(n):
	if n<0 : raise NegVal('Got ' + str(n) + ': -ve values not allowed')
	print('Accepted: ',n)

try:
	a = int(input('Enter Ist No: '))
	check(a)
except ValueError:
	print('Only integers allowed !!!')
except NegVal as e:
	print(e)
except:
	print('Pgm interrupted..')
print('pgm finished..!	')