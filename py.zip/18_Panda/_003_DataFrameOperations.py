import pandas as pd

print("/" * 50)
data = {'Item': ['Pen', 'Pencil', 'Bag', 'Book'], 'Price': [25, 12, 350, 22]}
df = pd.DataFrame(data)
print("\nDataFrame\n", df)

print("/" * 50, "\nAdding New Column")
df['Quantity'] = [50, 100, 10, 25]
print("\nDataFrame\n", df)

print("/" * 50, "\n Column Opearation\n Total = Price * Quantity")

df['Total'] = df['Price'] * df['Quantity']
print("\nDataFrame\n", df)

print("\nRemoving column using pop \n")
df.pop('Quantity')
print("\nDataFrame\n", df)

print("\nRemoving column using del \n")
del df['Total']
print("\nDataFrame\n", df)

print("/" * 50, "\n Row Opearation\n find row using loc")
print(df.loc[2])
print("/" * 50, "\n find row using iloc/index")
print(df.iloc[2])

print("\n Adding Row")
rw = pd.DataFrame([['Eraser', 5], ['Umberlla', 150]],
                  columns=['Item', 'Price'])
df = df.append(rw)
df = df.reset_index(drop=True)
print("\nDataFrame\n", df)
df = df.drop(0)
print("\nAfter Droping Row 0, DataFrame\n", df)
