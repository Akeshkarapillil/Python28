import pandas as pd

data = {'Item': ['Pen', 'Pencil', 'Bag', 'Book'], 'Price': [25, 12, 350, 22]}
df = pd.DataFrame(data)
df.to_excel('Sample.xlsx',index=False)