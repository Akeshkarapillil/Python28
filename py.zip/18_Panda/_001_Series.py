import pandas as pd
import numpy as np

# Series from ndarray
data = np.array(['red', 'green', 'blue', 'violet'])
s = pd.Series(data)
print("\nSeries from ndarray default index\n")
print(s)

s = pd.Series(data, index=[100, 101, 102, 103])
print("\nSeries from ndarray with defined index\n")
print(s)

# Series from Dictionary
data = {'r': 'red', 'g': 'green', 'b': 'blue', 'v': 'violet'}
s = pd.Series(data)
print("\nSeries from Dictionary with key as index\n")
print(s)
s = pd.Series(data, index=['rd', 'gn', 'be', 'vt'])
print("\nSeries from Dictionary with specified index\n")
print(s)

s = pd.Series(5, index=[1, 2, 3, 4, 5])
print("\nSeries from Scalar\n")
print(s)
s = pd.Series([100, 101, 102, 103, 104])
print(s)

print("\n Retrieve Ist three (s[:3])\n", s[:3])
print("\n Retrieve last three (s[-3:])\n", s[-3:])
