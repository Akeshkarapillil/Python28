# pip install sqlalchemy
from sqlalchemy import create_engine
# engine = create_engine('sqlite:///db/db_python')

# pip install mysqlclient
# mysql://username:password@localhost/shop
engine = create_engine('mysql://root@localhost/shop')
data = engine.execute("select * from stock").fetchall()
print(data)