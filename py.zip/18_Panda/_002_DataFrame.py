import pandas as pd

data = [1, 2, 3, 4, 5]
df = pd.DataFrame(data)
print("/" * 50)
print("\n List:", data)
print("\n DataFrame:\n")
print(df)
print("/" * 50)

data = [['Apple', 120], ['Mango', 70], ['Orange', 55]]
df = pd.DataFrame(data)
print("\n List:", data)
print("\n DataFrame:\n")
print(df)
print("/" * 50)
data = [['Apple', 120], ['Mango', 70], ['Orange', 55]]
df = pd.DataFrame(data, columns=['Item', 'Price'])
print("\n DataFrame with label:\n")
print(df)
print("/" * 50)

data = {'Item': ['Pen', 'Pencil', 'Bag', 'Book'], 'Price': [25, 12, 350, 22]}
df = pd.DataFrame(data)
print("\n Dictionary:", data)
print("\n DataFrame:\n")
print(df)
print("/" * 50)

data = [{'Item': 'Pen', 'Price': 25}, {'Item': 'Pencil', 'Price': 12},
        {'Item': 'Bag', 'Price': 350}, {'Item': 'Book', 'Price': 22}]
df = pd.DataFrame(data)
print("\n List of Dictionary:", data)
print("\n DataFrame:\n")
print(df)
print("/" * 50)

print("With User Index")
df = pd.DataFrame(data, index=['One', 'Two', 'Three', 'Four'])
print(df)
print("/" * 50)

print("With User Index & Specified Column")
df = pd.DataFrame(data, index=['One', 'Two', 'Three', 'Four'], columns=[
                  'Item'])
print(df)
print("/" * 50)
