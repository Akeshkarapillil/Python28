Data Structure in Panda
=======================
1) Series -> 1D labeled homogeneous array, sizeimmutable.
2) Data Frames -> General 2D labeled, size-mutable tabular structure 
                with potentially heterogeneously typed columns.
3) Panel -> General 3D labeled, size-mutable array.