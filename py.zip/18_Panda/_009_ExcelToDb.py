from sqlalchemy import create_engine
import pandas as pd
engine = create_engine('mysql://root@localhost/test')
p = pd.read_excel('MyDatas.xlsx')
df = pd.DataFrame(p)
print(df)
df.to_sql('stock', con=engine, if_exists='replace',index=False)
with engine.connect() as con:
    con.execute('ALTER TABLE stock ADD PRIMARY KEY (id);')
