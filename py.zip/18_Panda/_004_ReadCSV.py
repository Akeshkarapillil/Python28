import pandas as pd

p = pd.read_csv('MyDatas.csv')
# print(p)
# print(p.to_html())
print(p.to_json())
