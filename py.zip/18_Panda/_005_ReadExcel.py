
import pandas as pd

# pip install xlrd
p = pd.read_excel('MyDatas.xls')
# pip install openpyxl
# p = pd.read_excel('MyDatas.xlsx')
print(p)
# print(p.to_html())
# print(p.to_json())
