import mysql.connector as sql
import pandas as pd
conn = sql.connect(host='localhost', database='shop', user='root')
cur = conn.cursor()
cur.execute("select * from stock")
data =cur.fetchall()
conn.close()
# print(data)
df = pd.DataFrame(data)
print(df)
