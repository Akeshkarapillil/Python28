File Modes
===========================================================================

r	-> read only.
rb	-> read only binary mode.
r+	-> read & write, pointer will be in begining of the file.
rb+	-> read & write binary, pointer will be in begining of the file.
w	-> write only, overwrite or creates new file.
wb	-> write only binary, overwrite or creates new file.
w+	-> read & write, overwrite or creates new file.
wb+	-> read & write binary, overwrite or creates new file.
a	-> append mode, or create new file.
ab	-> append mode binary, or create new file.
a+	-> append and read,  or create new file.
ab+	-> append and read binary,  or create new file.
===========================================================================

001) File properties.
002) Write to file (text mode).
003) Read from file.
004) Read entire content from file.
005) rename,remove file. create, change, remove directory.

