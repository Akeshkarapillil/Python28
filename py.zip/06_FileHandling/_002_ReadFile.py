fo = open('test_1.txt','r')
a = fo.read()
fo.close()
print(a)