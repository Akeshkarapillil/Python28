import os

# os.rename('test_2.txt','test_2_1.txt')
# os.remove('test_2_1.txt')

# Create directory
# os.mkdir('test')

# Change directory
# os.chdir('test')
# get Current directory
# print(os.getcwd())

# remove directory
# os.rmdir('test')

