fo = open('test_1.txt','w')
fo.write("Welcome to python\nHi how are you ?")
fo.close()
print('Check test_1.txt file')