from googlesearch import search
import urllib
from bs4 import BeautifulSoup

num_page = 5
urls = search('Online Shoping',num_page)

print(len(urls))
print(urls)
for i in urls:
    print(i)

# for i in urls: 
#     print(i)
#     page = urllib.request.urlopen('https://www.myntra.com/')
#     print(page)