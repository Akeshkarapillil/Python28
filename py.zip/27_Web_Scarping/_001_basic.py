# import library BeautifulSoup
from bs4 import BeautifulSoup

#Creating BeautifulSoup object with an HTML content as parameter

soup = BeautifulSoup("<p class='asd'>Extremely bold</p>",'html.parser')

#Extract needed data
tag = soup.p

#Store the extracted data
print('Type:',type(tag))
print('Tag:',tag)
