from bs4 import BeautifulSoup as soup  
from urllib.request import urlopen as uReq  
  
# Request from the webpage  
myurl = "https://www.flipkart.com/search?q=iphones&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off"  
  
  
uClient  = uReq(myurl)  
page_html = uClient.read()
uClient.close()  
  
page_soup = soup(page_html, features="html.parser")  
  
  
# This variable held all html of webpage  
containers = page_soup.find_all("div",{"class": "_2kHMtA"})   

  
# Creating CSV File that will store all data   
filename = "product1.csv"  
f = open(filename,"w", encoding='utf-8')  
  
headers = "Product_Name,Pricing,Ratings\n"  
f.write(headers)  
  
for container in containers:  
    product_name = container.div.img["alt"]  
  
    price_container = container.find_all("div", {"class": "_30jeq3 _1_WHN1"})  
    price = price_container[0].text.strip()  
  
    rating_container = container.find_all("div",{"class":"_3LWZlK"})  
    ratings = rating_container[0].text  
    
    # ₹37,999
    price = price.replace('₹','Rs')
    price = price.replace(',','')

    # print(product_name.replace(",", "|")+","+price+","+ratings+"\n")  
    product_name = product_name.replace(",", "|")
    f.write(product_name+","+price+","+ratings+"\n") 
  
f.close()  