from bs4 import BeautifulSoup

soup = BeautifulSoup("<p class='asd'>Extremely bold</p>",'html.parser')

tag = soup.p

# Every Tag has Name
print('Tag Name:',tag.name)
