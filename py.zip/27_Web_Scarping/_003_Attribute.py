from bs4 import BeautifulSoup

soup = BeautifulSoup("<p class='asd xyz'>Extremely bold</p>",'html.parser')

tag = soup.p

# Every Tag has Name
print('Class Attribute:',tag['class'])
