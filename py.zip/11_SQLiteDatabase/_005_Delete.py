import sqlite3

#connect to database
conn = sqlite3.connect('db/db_python')
# sql = "delete from STOCK where id = 1"
sql = "delete from STOCK"
conn.execute(sql)
conn.commit()
print("Deleted Successfully")
conn.close()
