import sqlite3

#connect to database
conn = sqlite3.connect('db/db_python')
# sql = "DROP TABLE STOCK"
sql = """
CREATE TABLE STOCK(
    ID INT PRIMARY KEY,
    ITEM TEXT,
    PRICE REAL
)
"""
print("Database created...")
conn.execute(sql)
conn.close()