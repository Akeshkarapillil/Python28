import sqlite3

#connect to database
conn = sqlite3.connect('db/db_python')
sql = """
insert into STOCK values (1,'Apple',100),
(2,'Mango',35),(3,'Grapes',40),(4,'Orange',80)
"""
conn.execute(sql)
conn.commit()
print("Inserted Successfully")
conn.close()
