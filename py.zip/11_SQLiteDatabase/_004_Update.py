import sqlite3

#connect to database
conn = sqlite3.connect('db/db_python1')
sql = "update STOCK set price = 110 where id = 1"
conn.execute(sql)
conn.commit()
print("Updated Successfully")
conn.close()
