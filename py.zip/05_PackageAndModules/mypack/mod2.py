def disp2():
	print('Welcome from module 2')