def disp3():
	print('Welcome from module 3')
	
def disp3_1():
	print('Welcome from module 3 2nd disp()')