def disp1():
	print('Welcome from module 1')