from mypack.Mod1 import disp1
from mypack.mod2 import disp2
from mypack.mod3 import disp3,disp3_1