''' Mod_001 
def disp(str):
	print ("Welcome",str)
'''
# import module1,module2,module3,..
import Mod_001

Mod_001.disp('Jayan')