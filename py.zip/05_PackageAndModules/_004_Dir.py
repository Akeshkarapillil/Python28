import math

# list all functions
c = dir(math)

print(c)