#from Module import fun1,fun2,...
from Mod_001 import disp

disp('Anoop')