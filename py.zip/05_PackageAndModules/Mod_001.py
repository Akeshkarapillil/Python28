def disp(str):
	print ("Welcome",str)