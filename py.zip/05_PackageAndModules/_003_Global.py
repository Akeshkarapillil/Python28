cnt = 0
def count():
	global cnt
	cnt+=1
	

print('count = ',cnt)
count()
count()
print('count = ',cnt)