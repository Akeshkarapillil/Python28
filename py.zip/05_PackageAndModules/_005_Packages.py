'''
in mypack folder
#Mod1.py
def disp1():
	print('Welcome from module 1')

#Mod2.py
def disp2():
	print('Welcome from module 2')

#Mod3.py
def disp3():
	print('Welcome from module 3')
	
def disp3_1():
	print('Welcome from module 3 2nd disp()')

'''

import mypack
mypack.disp1()
mypack.disp2()
mypack.disp3()
mypack.disp3_1()