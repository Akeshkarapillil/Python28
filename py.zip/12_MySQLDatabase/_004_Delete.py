import mysql.connector as msql

# connect to database
conn = msql.connect(
    host='localhost',
    user='root',
    password='',
    database='test'
)
cur = conn.cursor()
# sql = "delete from STOCK where id = 1"
sql = "delete from STOCK"
cur.execute(sql)
conn.commit()
print("Deleted Successfully")
cur.close()
conn.close()
