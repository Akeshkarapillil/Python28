MySQL
======

CREATE TABLE STOCK(
	ID INT PRIMARY KEY,
	ITEM VARCHAR(50),
	PRICE FLOAT
)

python -m pip install mysql-connector-python

