# python -m pip install pyodbc
import pyodbc as msql

# connect to database
conn = msql.connect(
    'Driver={SQL Server};Server=.;Database=TestDB;uid=sa;pwd=sasa'
)
cur = conn.cursor()
# sql = "delete from STOCK where id = 1"
sql = "delete from STOCK"
cur.execute(sql)
conn.commit()
print("Deleted Successfully")
cur.close()
conn.close()
