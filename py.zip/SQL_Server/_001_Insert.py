# python -m pip install pyodbc
import pyodbc as msql

# connect to database
conn = msql.connect(
    'Driver={SQL Server};Server=.;Database=TestDB;uid=sa;pwd=sasa'
)
cur = conn.cursor()
sql = """
insert into STOCK values (1,'Apple',100),
(2,'Mango',35),(3,'Grapes',40),(4,'Orange',80)
"""
cur.execute(sql)
conn.commit()
print("Inserted Successfully")
cur.close()
conn.close()
