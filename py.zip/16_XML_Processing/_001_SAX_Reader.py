# SAX (Simple API for XML)
import xml.sax

class StockHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.item = ''
        self.quantity = ''
        self.price = ''
        self.tag = ''

    def startElement(self, tag, attribute):
        self.tag = tag
        if self.tag == "item":
            print("-"*40,"\nItem: ", attribute['name'])

    def endElement(self, tag):
        if tag == "quantity":
            print("Quantity: ", self.quantity)
        elif tag == "price":
            print("Price: ", self.price)

    def characters(self, content):
        if self.tag == "quantity":
            self.quantity = content
        elif self.tag == "price":
            self.price = content


parser = xml.sax.make_parser()
# parser.setFeature(xml.sax.handler.feature_namespaces, 0)
Handler = StockHandler()
parser.setContentHandler(Handler)
parser.parse("Sample.xml")
