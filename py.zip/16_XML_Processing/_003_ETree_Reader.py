# ElementTree

import xml.etree.ElementTree as et

tree = et.parse('Sample.xml')
root = tree.getroot()
print("Root: ", root.tag)

for child in root:
    print("#"*30)
    print(child.tag, ":", child.attrib['name'])
    for ch in child:
        print(ch.tag, ":", ch.text)
