import xml.etree.ElementTree as et

top = et.Element("enquiry")

# Record 1
sub = et.SubElement(top, "data")
name = et.SubElement(sub, "name")
contact = et.SubElement(sub, "contact")
name.text = "Anil"
contact.text = "55889638"

# Record 2
sub = et.SubElement(top, "data")
name = et.SubElement(sub, "name")
contact = et.SubElement(sub, "contact")
name.text = "Anna"
contact.text = "78589638"

et.ElementTree(top).write("t.xml")

# print(et.tostring(top))

from ElementTree_pretty import prettify
print(prettify(top))
