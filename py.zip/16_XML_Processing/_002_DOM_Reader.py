# Document Object Model (DOM)
from xml.dom.minidom import parse
import xml.dom.minidom

dom = xml.dom.minidom.parse("Sample.xml")
coll = dom.documentElement
items = coll.getElementsByTagName("item")

for it in items:
    print("$"*30)
    if it.hasAttribute('name'):
        print("Item: ",it.getAttribute('name'))
    print("Price: ", it.getElementsByTagName("quantity")[0].childNodes[0].data)
    print("Quantity: ", it.getElementsByTagName("price")[0].childNodes[0].data)