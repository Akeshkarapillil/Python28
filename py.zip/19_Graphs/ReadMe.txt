Sr.No.	Character & Description
====== =========== ================
1	'-'     Solid line style
2	'--'    Dashed line style
3	'-.'    Dash-dot line style
4	':'     Dotted line style
5	'.'     Point marker
6	','     Pixel marker
7	'o'     Circle marker
8	'v'     Triangle_down marker
9	'^'     Triangle_up marker
10	'<'     Triangle_left marker
11	'>'     Triangle_right marker
12	'1'     Tri_down marker
13	'2'     Tri_up marker
14	'3'     Tri_left marker
15	'4'     Tri_right marker
16	's'     Square marker
17	'p'     Pentagon marker
18	'*'     Star marker
19	'h'     Hexagon1 marker
20	'H'     Hexagon2 marker
21	'+'     Plus marker
22	'x'     X marker
23	'D'     Diamond marker
24	'd'     Thin_diamond marker
25	'|'     Vline marker
26	'_'     Hline marker

///////////////////////////////////////////

Character       Color
=========      ======
'b'	            Blue
'g'	            Green
'r'	            Red
'c'	            Cyan
'm'	            Magenta
'y'	            Yellow
'k'	            Black
'w'	            White