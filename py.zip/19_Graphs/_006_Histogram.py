from matplotlib import pyplot as plt
import numpy as np

a = np.array([22, 87, 5, 43, 56, 73, 55, 54, 11, 20, 51, 5, 79, 31, 27])
_bins = [0, 20, 40, 60, 80, 100]

print("\nArray: \n", a)
print("\nBins: \n", _bins)
plt.hist(a, bins=_bins, alpha=0.7, rwidth=.9)
plt.title("histogram")
plt.show()
