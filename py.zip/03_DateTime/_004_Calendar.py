import calendar

cal = calendar.month(2014,8)
print(cal)

c = calendar.TextCalendar(calendar.SUNDAY)
str = c.formatmonth(2020,1)
print(str)

# c = calendar.HTMLCalendar(calendar.SUNDAY)
# str = c.formatmonth(2020,1)
# print(str)