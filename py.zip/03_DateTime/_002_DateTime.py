from datetime import datetime

now = datetime.now()
current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

now = datetime.now().time() # time object
print("now =", now)

