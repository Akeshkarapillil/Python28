import calendar
year = int(input('Year: '))
month = int(input('Month: '))
week = int(input('Week Day: '))
cal = calendar.monthcalendar(year,month)
print(cal[week])
print("In",calendar.month_name[month] , cal[week][calendar.MONDAY],"is Monday in Week",week)