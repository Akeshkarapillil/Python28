import socket
import datetime as dt

s = socket.socket()

host = socket.gethostname()
port = 12345

s.bind((host, port))
s.listen(5)

while True:
    conn, addr = s.accept()		# accept the connection

    data = conn.recv(1024)
    t1 = dt.datetime.now()
    while data:			        # till data is coming
        print(data.decode())
        data = conn.recv(1024)
    print("All Data Received")  # Will execute when all data is received
    conn.close()
    break
t2 = dt.datetime.now()
print("Time Taken: ", t2-t1)
