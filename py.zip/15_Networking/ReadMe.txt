UDP(USER DATAGRAM PROTOCOL) 
============================
    1) UDP is a connection-less, unreliable, datagram protocol.
    2) UDP is lightweight.
    3) UDP supports Broadcasting.

TCP(TRANSMISSION CONTROL PROTOCOL) 
==================================
    1) TCP is instead connection-oriented, reliable and stream based.
    2) TCP is heavy-weight.
    3) TCP doesn’t supports Broadcasting.
