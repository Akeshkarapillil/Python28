from django.db import models

# Create your models here.


class Stock(models.Model):
    # setting auto_increment
    sid = models.AutoField(primary_key=True)
    item = models.CharField(max_length=30)
    price = models.DecimalField(max_digits=7, decimal_places=2)
    qty = models.IntegerField()

    class Meta:
        db_table = 'stock'


class Author(models.Model):
    aid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    lifespan = models.CharField(max_length=30)
    area = models.CharField(max_length=100)

    class Meta:
        db_table = 'author'

class Book(models.Model):
    bid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    author = models.ForeignKey('Author',on_delete=models.RestrictedError)

    class Meta:
        db_table = 'book'

class Profile(models.Model):
    name = models.CharField(max_length=50)
    pic = models.ImageField(upload_to = 'pic_uploads')

    class Meta:
        db_table = 'profile'