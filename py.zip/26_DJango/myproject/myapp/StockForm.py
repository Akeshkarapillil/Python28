from django import forms


class StockF(forms.Form):
    item = forms.CharField()
    price = forms.CharField(widget=forms.NumberInput())
    qty = forms.CharField(widget=forms.NumberInput())
