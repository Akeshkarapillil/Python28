from datetime import datetime
from django.urls import path
from myapp.views import hello, helloWorld, \
    welcome, addNos, stockDetails, temp_1,\
    mangStock, books, goog, viewMsg, viewMessage,\
    sendEmail, GenericPage1, Stock, addStock, \
    SaveProfile, writeCookies, readCookies, \
    writeSessions, readSessions

from django.views.generic import TemplateView, ListView


urlpatterns = [
    path('hello/', hello, name='hello'),
    path('helloworld/', helloWorld, name='helloW'),
    path('welcome/<name>', welcome, name='wel'),
    path('sum/<int:x>/<int:y>', addNos, name='sum'),
    path('stocks', stockDetails, name='stock'),
    path('temp', temp_1, name='temp'),
    path('mangStock/<int:op>', mangStock, name='mangStock'),
    path('books/<int:op>', books, name='books'),
    path('goog/', goog, name='goog'),
    path('viewMsg/', viewMsg, name='viewMsg'),
    path('viewMessage/<msg>/<size>/<col>', viewMessage, name='viewMessage'),
    path('sendEmail/', sendEmail, name='sendEmail'),
    path('gen_1/', GenericPage1.as_view(), name='generic_1'),
    path('gen_2/', TemplateView.as_view(template_name='generic_1.html'),
         name='generic_2'),
    path('stocklist/', ListView.as_view(model=Stock,
                                        template_name='stockList.html', context_object_name="stocks")),
    path('addStock/', TemplateView.as_view(template_name='StockForm.html')),
    path('saveStock/', addStock),
    path('saveProfile/', SaveProfile),
    path('profile/', TemplateView.as_view(template_name="profile.html")),
    path('writeCookies/<name>', writeCookies),
    path('readCookies/', readCookies),
    path('writeSessions/<name>', writeSessions),
    path('readSessions/', readSessions),
]
