from datetime import datetime
from myapp.forms import ProfileForm
from myapp.models import Profile
from django.views.generic import TemplateView
from django.core.mail import send_mail
from myapp.models import Stock, Author, Book
from django.http import HttpResponse
from django.shortcuts import render, redirect
from myapp.StockForm import StockF


# Create your views here.


def hello(req):
    return HttpResponse("<h1>Hello World !!!</h1>")


def helloWorld(req):
    return render(req, 'hello.html', {})


def welcome(req, name):
    return HttpResponse("<h1>Welcome %s !!!</h1>" % name)


def addNos(req, x, y):
    s = "<h1> %s + %s = %s </h1>" % (x, y, x+y)
    return HttpResponse(s)


def stockDetails(req):
    stockItems = {"stocks": [
        {"id": "100", "item": "Apple", "price": "110", "type": "fr"},
        {"id": "101", "item": "Orange", "price": "35", "type": "fr"},
        {"id": "102", "item": "Cabage", "price": "30", "type": "veg"},
        {"id": "103", "item": "Banana", "price": "25", "type": "fr"},
        {"id": "104", "item": "Potato", "price": "48", "type": "veg"},
    ]}
    return render(req, 'stock.html', stockItems)


def temp_1(req):
    d = {
        "msg": "Hello My Template !!!",
        "col": "tomato"
    }
    return render(req, 'innerToTemplate.html', d)


# Manage Record


def mangStock(req, op):
    s = ''
    if op == 1:
        # Insert
        s1 = Stock(sid="1", item="Apple", price="100", qty="20")
        s1.save()
        s1 = Stock(sid="2", item="Orange", price="50", qty="15")
        s1.save()
        s1 = Stock(sid="3", item="Grapes", price="160", qty="50")
        s1.save()
        s1 = Stock(sid="4", item="Mango", price="30", qty="12")
        s1.save()
        s1 = Stock(sid="5", item="Pineapple", price="25", qty="10")
        s1.save()
        s = 'Saved'
    elif op == 2:
        # Update
        s1 = Stock(sid="1", item="Apple", price="100", qty="50")
        s1.save()
        s = 'Updated'
    elif op == 3:
        # Delete
        s1 = Stock.objects.get(sid="4")
        s = 'Deleted: %s' % (s1.item)
        s1.delete()
    elif op == 4:
        # Select
        res = Stock.objects.all()
        # res = Stock.objects.order_by('item')
        s = ''
        for i in res:
            s += "%s, %s, %s, %s <br/>" % (i.sid, i.item, i.price, i.qty)
    return HttpResponse(s)


def books(req, op):
    s = ''
    if op == 1:
        auths = [
            {
                "name": "William Shakespeare",
                "lifespan": "1564-1616",
                "area": "English playwright, poet, and actor"
            },
            {
                "name": "Charles Dickens",
                "lifespan": "1812-1870",
                "area": "English writer and social critic"
            }, {
                "name": "Vaikom Muhammad Basheer",
                "lifespan": "1908-1994",
                "area": "Malayalam writer, humanist, freedom fighter, novelist and short story writer"
            },
            {
                "name": "Thakazhi Sivasankara Pillai",
                "lifespan": "1912-1999",
                "area": "Malayalam  novelist and short story writer"
            }
        ]
        books = [
            {"name": "Hamlet", "author": 0},
            {"name": "Romeo and Juliet", "author": 0},
            {"name": "King Lear", "author": 0},
            {"name": "A Christmas Carol", "author": 1},
            {"name": "Oliver Twist", "author": 1},
            {"name": "Pathummayude Aadu", "author": 2},
            {"name": "Balyakalasakhi", "author": 2},
            {"name": "Mathilukal", "author": 2},
            {"name": "Chemmeen", "author": 3},
            {"name": "Kayar", "author": 3},
            {"name": "Randidangazhi", "author": 3},
        ]
        # Clear Previous Records
        Book.objects.all().delete()
        Author.objects.all().delete()

        authors = []
        for a in auths:
            # s+= str(a['name'])
            auth = Author(name=a['name'],
                          lifespan=a['lifespan'], area=a['area'])
            authors.append(auth)
            auth.save()

        for b in books:
            # s += str(b['author'])
            book = Book(name=b['name'], author=authors[int(b['author'])])
            book.save()
        s += "Saved All"
    else:
        # Select
        # res = Stock.objects.all()
        res = Book.objects.all()
        s = '<pre style="color: tomato;font-weight:bolder;font-size: 14px">'
        s += '='*170
        s += '\n| %5s | %-25s | %-35s | %-10s | %-80s |\n' % (
            'SlNo', 'Book', 'Author', 'Lifespan', 'About Author')
        s += '='*170
        for i in res:
            au = i.author
            s += "\n| %5s | %-25s | %-35s | %-10s | %-80s |\n" % (
                i.bid, i.name, au.name, au.lifespan, au.area)
            s += '-'*170
        s += "</pre>"
    return HttpResponse(s)

# For to redirect to another site


def goog(req):
    return redirect("https://www.google.com")

# Redirect to another view


def viewMsg(req):
    return redirect(viewMessage, "Welcome", 1, "red")


def viewMessage(req, msg, size, col):
    s = "<h%s style='color: %s'> %s </h%s>" % (size, col, msg, size)
    return HttpResponse(s)


def sendEmail(req):
    res = send_mail('Hello DJango', 'Welcome To DJango !!!',
                    'cts.students.project@gmail.com', ['sherin_kj@yahoo.com'])
    return HttpResponse(res)


class GenericPage1(TemplateView):
    template_name = "generic_1.html"


def addStock(req):
    if req.method == 'POST':
        sf = StockF(req.POST)
        if sf.is_valid():
            it = sf.cleaned_data['item']
            pr = sf.cleaned_data['price']
            qt = sf.cleaned_data['qty']
            st = Stock(item=it, price=pr, qty=qt)
            st.save()
    else:
        sf = StockF()
    return render(req, 'StockForm.html', {"key": "Saved"})


def SaveProfile(req):
    saved = False
    if req.method == 'POST':
        pf = ProfileForm(req.POST, req.FILES)
        if pf.is_valid():
            p = Profile()
            p.name = pf.cleaned_data['name']
            p.pic = pf.cleaned_data['pic']
            p.save()
            saved = True
        else:
            pf = ProfileForm()
        return render(req, 'saved.html', locals())


def writeCookies(req, name):
    res = render(req, 'createCookie.html', {
        "name": name,"app" : "Cookies"})
    res.set_cookie('last_connection', datetime.now())
    res.set_cookie('name', name)
    return res


def readCookies(req):
    name = "Unknown"
    last = "Donn't know who connected last"
    if 'name' in req.COOKIES and 'last_connection' in req.COOKIES:
        name = req.COOKIES['name']
        last = req.COOKIES['last_connection']
    return render(req, 'readCookies.html', {"name": name, "last": last})


def writeSessions(req, name):
    res = render(req, 'createCookie.html', {
        "name": name,"app" : "Sessions"})
    req.session['last_connection'] = str(datetime.now())
    req.session['name'] = name
    return res

def readSessions(req):
    name = "Unknown"
    last = "Donn't know who connected last"
    if req.session.has_key('name') and req.session.has_key('last_connection'):
        name = req.session['name']
        last = req.session['last_connection']
    return render(req, 'readCookies.html', {"name": name, "last": last})