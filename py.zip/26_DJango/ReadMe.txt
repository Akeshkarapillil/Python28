python -m pip install Django==3.1.5


Recreating models
===================
delete db.sqlite3 file then
C:/> python manage.py makemigrations
C:/> python manage.py migrate









