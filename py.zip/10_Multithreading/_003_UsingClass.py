import  threading, time

class MyThread(threading.Thread):
    def run(self):
        for i in range(1,11):
            print(i)
            time.sleep(1)


t1 = MyThread()
t1.start()
