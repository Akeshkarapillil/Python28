import threading
import time

def disp_1(name):
    for i in range(1, 11):
        print(i, name)
        time.sleep(1)

def disp_2(name):
    for i in range(11, 21):
        print(i, name)
        time.sleep(1)

x = threading.Thread(target=disp_1, args=("Anooja",))
y = threading.Thread(target=disp_2, args=("Bhanu",))

x.start()
y.start()

x.join()
#y.join()

for i in range(100, 111):
    print(i, "main")
    time.sleep(1)
