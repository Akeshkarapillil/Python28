import _thread, time

t1 = True; t2 = True 

def disp_1(name):
    global t1
    for i in range(1,11):
        print(i,name)
        time.sleep(1)
    t1 = False

def disp_2(name):
    global t2
    for i in range(11,21):
        print(i,name)
        time.sleep(1)
    t2 = False

_thread.start_new_thread(disp_1,("Anooja",))
_thread.start_new_thread(disp_2,("Bhanu",))

while t1 or t2: pass
