-- will create/open db
> use DatabaseName
-- Shows connected db
> db
-- show databases
> show dbs
-- insert record
> db.book.insert({"name":"Python Basics"})
-- drop db
> db.dropDatabase()
-- Creating collections
> db.createCollection(CollectionName)
-- dropping collection
> db.CollectionName.drop()
-- Show all collections
> db.show collections
-- Query from collection
> db.CollectionName.find()
> db.CollectionName.find().pretty()
> db.stock.find({"id":{$gt:2}})