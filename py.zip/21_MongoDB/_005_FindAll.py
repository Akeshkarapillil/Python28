import pymongo

# Connect
myClient = pymongo.MongoClient()
# Open DB
myDb = myClient["mydb"]
# Select Collection
myCol = myDb["stock"]
# Fetch All record
x = myCol.find()
for r in x:
    print(r)