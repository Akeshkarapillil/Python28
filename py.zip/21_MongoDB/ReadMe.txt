myquery = { "address": "Mountain 21" }
mycol.delete_one(myquery)

myquery = { "address": {"$regex": "^S"} }
mycol.delete_many(myquery)

# Delete all
x = mycol.delete_many({})
print(x.deleted_count, " documents deleted.")

# Drop Collection
mycol.drop()

# update
myquery = { "address": "Valley 345" }
newvalues = { "$set": { "address": "Canyon 123" } }
mycol.update_one(myquery, newvalues)

myquery = { "address": { "$regex": "^S" } }
newvalues = { "$set": { "name": "Minnie" } }
x = mycol.update_many(myquery, newvalues)
print(x.modified_count, "documents updated.")

# Limit
myresult = mycol.find().limit(5)

