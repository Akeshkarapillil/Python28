import pymongo

# Connect
myClient = pymongo.MongoClient()
# Open DB
myDb = myClient["mydb"]
# Select Collection
myCol = myDb["stock"]
# Fetch one record
x = myCol.find_one()
print(x)