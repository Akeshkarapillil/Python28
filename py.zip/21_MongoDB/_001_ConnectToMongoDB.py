# python -m pip install pymongo
import pymongo

# mClient = pymongo.MongoClient("mongodb://localhost:27017")
mClient = pymongo.MongoClient()
print(mClient.list_database_names())