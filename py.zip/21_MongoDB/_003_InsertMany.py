import pymongo
# Connecting
mClient = pymongo.MongoClient()
# select/create database
myDb = mClient["mydb"]
# select/create collection
myCol = myDb["stock"]

# Records
myRecs = [
    {"_id": "2", "item": "Blue Berry", "Price": "460"},
    {"_id": "3", "item": "Grapes", "Price": "120"},
    {"_id": "4", "item": "Orange", "Price": "40"},
    {"_id": "5", "item": "Pineapple", "Price": "20"},
    {"_id": "6", "item": "Black Berry", "Price": "360"}
]
x = myCol.insert_many(myRecs)
print("Inerted with ids: ", x.inserted_ids)
