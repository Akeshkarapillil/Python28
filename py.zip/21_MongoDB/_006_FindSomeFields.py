import pymongo

# Connect
myClient = pymongo.MongoClient()
# Open DB
myDb = myClient["mydb"]
# Select Collection
myCol = myDb["stock"]

# Exclude _id coloumn
x = myCol.find({"_id":"4"},{"_id" : 0,"Price":1})

# Fetch Only item (by default _id will show, so suppress with 0)
#x = myCol.find({},{"_id" : 0,"item" : 1})

for r in x:
    print(r)