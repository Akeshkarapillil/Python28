import pymongo

# Connect
myClient = pymongo.MongoClient()
# Open DB
myDb = myClient["mydb"]
# Select Collection
myCol = myDb["stock"]

# where _id = 4
#x = myCol.find({"_id": "4"})

# where _id > 4
# x = myCol.find({"_id":{"$gt":"3"}})

'''
$gt, $lt, $gte, $lte
'''

# Ends with e
# x = myCol.find({"item":{"$regex":"e$"}})

# Starts with A
# x = myCol.find({"item":{"$regex":"^A"}})

# sort Ascending
# x = myCol.find().sort("item")
# sort Descending
x = myCol.find().sort("item",-1)
for r in x:
    print(r)
