import pymongo
# Connecting
mClient = pymongo.MongoClient()
# select/create database
myDb = mClient["mydb"]
# select/create collection
myCol = myDb["stock"]

# Record
myRec = {"item" : "Apple","Price" : "110"}
x = myCol.insert_one(myRec)
print("Inerted with id: ", x.inserted_id)

myRec = {"_id":"1","item" : "Mango","Price" : "60"}
x = myCol.insert_one(myRec)
print("Inerted with id: ", x.inserted_id)
