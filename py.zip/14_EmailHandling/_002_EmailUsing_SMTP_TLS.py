import smtplib
import ssl

port = 587  # For TLS(Transport Layer Security)

# Create a secure SSL(Secure Sockets Layer) context
context = ssl.create_default_context()

with smtplib.SMTP("smtp.gmail.com", port) as server:
    # Using TLS
    server.ehlo() # Can be omitted
    server.starttls(context=context) # Secure the connection
    server.ehlo() # Can be omitted

    server.login("cts.students.project@gmail.com", "cts@123456")
    # TODO: Send email here
    sender_email="cts.students.project@gmail.com"
    receiver_email="sherin_kj@yahoo.com"
    message="""
    Hello, this is test message.
    <b>Test HTML tag TLS</b>
    """
    server.sendmail(sender_email, receiver_email, message)
print("Message mailed !!!")