import smtplib
import ssl

port = 465  # For SSL

# Create a secure SSL(Secure Sockets Layer) context
context = ssl.create_default_context()

with smtplib.SMTP_SSL("smtp.gmail.com", port, context=context) as server:
    server.login("iiat.cts.projects@gmail.com", "Iiatcts@123456")
    # TODO: Send email here
    sender_email="cts.students.project@gmail.com"
    receiver_email="akeshkarapillil@gmail.com"
    message="""
    Hello, this is test message.
    <b>Test HTML tag</b>
    """
    server.sendmail(sender_email, receiver_email, message)
print("Message mailed !!!")