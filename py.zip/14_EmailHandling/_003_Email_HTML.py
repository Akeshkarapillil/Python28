import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

port = 587
sender_email = "cts.students.project@gmail.com"
password = "cts@123456"
receiver_email = "sherin_kj@yahoo.com"
msg = MIMEMultipart("alternative")
msg["Subject"] = "Test Mail"
msg["From"] = sender_email
msg["To"] = receiver_email

# HTML Message
html = """
    <html>
        <body>
            <h1>Hello World !!!</h1>
            <p align='justify'>
                Hi, this is test <b>html</b> message from <font color='red'>python email</font>.
            </p>
        </body>
    </html>
"""

part1 = MIMEText(html,"html")

# add to message
msg.attach(part1)

context = ssl.create_default_context()
with smtplib.SMTP("smtp.gmail.com", port) as server:
    # Using TLS
    server.ehlo() # Can be omitted
    server.starttls(context=context) # Secure the connection
    server.ehlo() # Can be omitted

    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, msg.as_string())

print("Message mailed !!!")