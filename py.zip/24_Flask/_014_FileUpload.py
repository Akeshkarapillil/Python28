from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
app = Flask(__name__)


@app.route('/')
def init():
    return render_template('_014_FileUpload.html')


@app.route('/uploadMe', methods=['POST'])
def uploader():
    f = request.files['myFile']
    # f.save(f.filename)
    # f.save('2.gif')
    # suggested way
    f.save('uploads/' + secure_filename(f.filename))
    return 'Upload success fully'


app.run(debug=True)
