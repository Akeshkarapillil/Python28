from flask import Flask, redirect, url_for, request

app = Flask(__name__)


@app.route('/success/<name>')
def success(name):
    return "Welcome %s" % name


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        un = request.form['uname']
        return redirect(url_for('success', name=un))
    else:
        un = request.args.get('uname')
        return redirect(url_for('success', name=un))

app.run()