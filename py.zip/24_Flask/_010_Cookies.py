from flask import Flask, render_template, request, make_response

app = Flask(__name__)


@app.route('/')
def hello():
    return render_template('_010_SetCookies.html')


@app.route('/result', methods=['POST'])
def result():
    name = request.form['name']
    place = request.form['country']
    resp = make_response(render_template('_010_SetCookies.html'))
    resp.set_cookie('name', name)
    resp.set_cookie('place', place)
    return resp


@app.route('/show')
def show():
    name = request.cookies.get('name')
    place = request.cookies.get('place')
    return "<h1>Hi "+name+" from "+place+"</h1>"


app.run(debug=True)
