# pip install Flask-Mail
from flask import Flask
from flask_mail import Mail, Message

app = Flask(__name__)

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_DEFAULT_SENDER'] = 'iiat.cts.projects@gmail.com'
app.config['MAIL_USERNAME'] = 'iiat.cts.projects@gmail.com'
app.config['MAIL_PASSWORD'] = 'Iiatcts@123456'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)

@app.route('/')
def index():
    _topic = 'Helloo It\'s a sample mail sending from Flask'
    _sub = 'Flask Email Test'
    _from = ''
    _to = ['sherin_kj@yahoo.com']
    msg = Message(_sub,sender = _from,recipients= _to)
    msg.body = _topic
    mail.send(msg)
    return "Sent"

app.run(debug=True)