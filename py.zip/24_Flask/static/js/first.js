var clickMe = function () {
    var name = prompt('Name Please !')
    document.getElementById('x').innerHTML = "Welcome " + name
}