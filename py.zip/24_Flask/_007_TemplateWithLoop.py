from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def hello():
    items = [
        {'id': 1, 'item': 'Apple', 'price': 60},
        {'id': 2, 'item': 'Orange', 'price': 40},
        {'id': 3, 'item': 'Grapes', 'price': 50},
        {'id': 4, 'item': 'Mango', 'price': 55}
    ]
    return render_template('_007_Stock.html', stock=items)


app.run(debug=True)
