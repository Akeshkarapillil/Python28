from flask import Flask,render_template

app = Flask(__name__)

@app.route('/hello/<u>')
def hello(u):
    return render_template('_005_hello.html',name=u)

app.run(debug=True)