from _016_FlaskForm import RegistrationForm
from flask import Flask, request, redirect, render_template, flash, url_for
app = Flask(__name__)
app.secret_key = "my key"

@app.route('/', methods=['GET', 'POST'])
def register():
    form = RegistrationForm(request.form)
    if request.method == 'POST' and form.validate():
        flash('Thanks for registering')
        return "Registered !!!"
    flash('All Fields required !!!')
    return render_template('_016_Register.html', form=form)



app.run(debug=True)
