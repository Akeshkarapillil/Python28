from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def hello():
    return render_template('_009_Forms.html')


@app.route('/result', methods=['POST'])
def result():
    if request.method == 'POST':
        res = request.form
        return render_template('_009_Result.html', r=res)


app.run(debug=True)
