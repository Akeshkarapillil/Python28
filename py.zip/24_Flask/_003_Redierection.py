from flask import Flask, redirect, url_for

app = Flask(__name__)


@app.route('/admin')
def adminPage():
    return "<h1>Welcome Admin</h1>"


@app.route('/guest/<name>')
def guestPage(name):
    return "<h1>Welcome %s</h1>" % name


@app.route('/page/<url>')
def page(url):
    if url == 'admin':
        return redirect(url_for('adminPage'))
    else:
        return redirect(url_for('guestPage', name=url))


app.run(debug=True)
