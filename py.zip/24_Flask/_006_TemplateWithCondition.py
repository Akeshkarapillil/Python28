from flask import Flask, render_template

app = Flask(__name__)


@app.route('/year/<int:y>')
def hello(y):
    return render_template('_006_LeapYear.html', year=y)


app.run(debug=True)
