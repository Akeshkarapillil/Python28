from flask import Flask, render_template, request, session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'any random key set here'


@app.route('/')
def hello():
    return render_template('_010_SetCookies.html')


@app.route('/result', methods=['POST'])
def result():
    session['name'] = request.form['name']
    session['place'] = request.form['country']
    return redirect(url_for('show'))


@app.route('/show')
def show():
    if 'name' in session:
        name = session['name']
        place = session['place']
        return "<h1>Hi "+name+" from "+place+"</h1>"
    else:
        return "<h2>No sessions..</h2>"


@app.route('/signout')
def signout():
    session.pop('name', None)
    return "<h2>Clearing Sessions...</h2>"


app.run(debug=True)
