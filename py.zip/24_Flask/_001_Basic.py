from flask import Flask

app = Flask(__name__)

# http://127.0.0.1:5000
@app.route('/')
def hello():
    return 'Hello, World!'

# http://127.0.0.1:5000/wel
@app.route('/wel')
def welcome():
    return "Welcome To Flask !!!"

def hi_all():
    return "Hi everyone !"

app.add_url_rule('/hi','',hi_all)

# if __name__ == '__main__':
#     app.run(debug=True)
# app.run(debug=True,port=1000)
app.run(debug=True)
