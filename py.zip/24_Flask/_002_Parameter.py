from flask import Flask

app = Flask(__name__)

# http://127.0.0.1:5000/wel/Sherin/
@app.route('/wel/<name>/')
def welcome(name):
    return "<h1>Welcome %s </h1>" % name

@app.route('/ver/<int:v>/')
def version(v):
    return "<h1>Version is %s </h1>" % v


app.run(debug=True)