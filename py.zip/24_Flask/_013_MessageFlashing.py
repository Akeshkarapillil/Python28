from flask import Flask, flash, redirect, render_template, request, url_for

app = Flask(__name__)
app.secret_key = 'my secret key'


@app.route('/')
def index():
    return render_template('_013_index.html')


@app.route('/login',methods=['GET','POST'])
def login():
    error = None

    if request.method == 'POST':
        if request.form['uname'] != 'admin' or \
                request.form['pwd'] != 'admin':
            error = 'Invalid User Name or Password !!!'
        else:
            flash('You were successfully logged in')
            return redirect(url_for('index'))
    return render_template('_013_Login.html', error=error)


app.run(debug=True)
