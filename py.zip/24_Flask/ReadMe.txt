pip install Flask

Deploying on Apache Server Windows
==================================

Go to the Visual Studio download page, expand Tools for Visual Studio, and click the download link for the Build Tools (currently 2019). Execute the installer, select C++ build tools, on the right side you can un-check some optional features, but you need at least MSVC v142 and Windows 10 SDK.

set "MOD_WSGI_APACHE_ROOTDIR=C:/MyPrograms/xampp/apache"
pip install mod_wsgi
https://dev.to/willmvs/flask-deployment-on-windows-139b
Deploying on Apache Server Linux
==================================
command to install mod_wsgi:
////////////////////////////
sudo apt-get install libapache2-mod-wsgi python-dev

To enable mod_wsgi, run the following command:
/////////////////////////////////////////////
sudo a2enmod wsgi 

Step Two – Creating a Flask App
//////////////////////////////
cd /var/www 
sudo mkdir FlaskApp
cd FlaskApp
sudo mkdir FlaskApp
cd FlaskApp
sudo mkdir static templates

sudo nano __init__.py 

from flask import Flask
app = Flask(__name__)
@app.route("/")
def hello():
    return "Hello, I love Digital Ocean!"
if __name__ == "__main__":
    app.run()

Install Flask
/////////////

sudo apt-get install python-pip 
sudo pip install virtualenv 
sudo virtualenv venv
source venv/bin/activate
sudo pip install Flask 

run the following command to test if the installation is successful and the app is running:
/////////////////////////////////////////////////////////////////////////////////////////
sudo python __init__.py 

To deactivate the environment, give the following command:
/////////////////////////////////////////////////////////
deactivate

Configure and Enable a New Virtual Host
/////////////////////////////////////
sudo nano /etc/apache2/sites-available/FlaskApp
sudo nano /etc/apache2/sites-available/FlaskApp.conf

<VirtualHost *:80>
		ServerName mywebsite.com
		ServerAdmin admin@mywebsite.com
		WSGIScriptAlias / /var/www/FlaskApp/flaskapp.wsgi
		<Directory /var/www/FlaskApp/FlaskApp/>
			Order allow,deny
			Allow from all
		</Directory>
		Alias /static /var/www/FlaskApp/FlaskApp/static
		<Directory /var/www/FlaskApp/FlaskApp/static/>
			Order allow,deny
			Allow from all
		</Directory>
		ErrorLog ${APACHE_LOG_DIR}/error.log
		LogLevel warn
		CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>

sudo a2ensite FlaskApp

Create the .wsgi File
///////////////////////

cd /var/www/FlaskApp
sudo nano flaskapp.wsgi 

#!/usr/bin/python
import sys
import logging
logging.basicConfig(stream=sys.stderr)
sys.path.insert(0,"/var/www/FlaskApp/")

from FlaskApp import app as application
application.secret_key = 'Add your secret key'

Now your directory structure should look like this:
/////////////////////////////////////////////////
|--------FlaskApp
|----------------FlaskApp
|-----------------------static
|-----------------------templates
|-----------------------venv
|-----------------------__init__.py
|----------------flaskapp.wsgi

Restart Apache
///////////////
sudo service apache2 restart 
