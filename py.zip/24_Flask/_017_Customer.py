from flask_wtf import Form
from wtforms import TextField, SubmitField, validators, RadioField, IntegerField, SelectField, BooleanField, PasswordField


class Customer(Form):
    name = TextField("Name", [validators.DataRequired(message='Name Required'), validators.regexp(
        '^[a-zA-Z ]+$', message='Only letters and space'), validators.Length(min=3, max=20)])
    email = TextField("Email", [validators.DataRequired(), validators.Email()])
    passwd = PasswordField("Password", [validators.DataRequired()])
    cpasswd = PasswordField("Confirm Password", [validators.DataRequired(
    ), validators.EqualTo('passwd', message="Password not matching")])
    gender = RadioField('Gender', choices=[
                        ('M', 'Male'), ('F', 'Female')], validators=[validators.DataRequired()], default='M')
    age = IntegerField('Age', [validators.DataRequired(
        'Invalid Age'), validators.NumberRange(min=15, max=50)])
    lang = SelectField('Language', choices=[
                       ('c', 'C'), ('cpp', 'C++'), ('py', 'Python')])
    agree = BooleanField(
        'I Agree', [validators.DataRequired('please accept the agrement')])
    submit = SubmitField("Submit")
