from _017_Customer import Customer
from flask import Flask, render_template, request

app = Flask(__name__)
app.secret_key = "my key"


@app.route('/', methods=['GET', 'POST'])
def reg():
    form = Customer()
    if request.method == 'POST':
        if form.validate():
            return "Registered !!! "
    return render_template('_017_Customer.html', form=form)


app.run(debug=True)
