from flask import Flask, redirect, url_for, render_template, request, abort

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('_012_Login.html')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        if request.form['uname'] == 'admin':
            return redirect(url_for('success'))
        else:
            abort(401)
    else:
        return redirect(url_for('index'))


@app.route('/success')
def success():
    return 'logged successfully'


app.run(debug=True)
'''
    400 − for Bad Request
    401 − for Unauthenticated
    403 − for Forbidden
    404 − for Not Found
    406 − for Not Acceptable
    415 − for Unsupported Media Type
    429 − Too Many Requests
'''
