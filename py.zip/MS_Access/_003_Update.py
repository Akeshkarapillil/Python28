import pyodbc as msql

# connect to database
conn = msql.connect(
    'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=db/TestDB.accdb;'
)
cur = conn.cursor()
sql = "update STOCK set price = 110 where id = 1"
cur.execute(sql)
conn.commit()
print("Updated Successfully")
cur.close()
conn.close()
