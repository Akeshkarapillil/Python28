# python -m pip install pyodbc
import pyodbc as msql

# connect to database
conn = msql.connect(
    'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=db/TestDB.accdb;'
)
cur = conn.cursor()
sql = "insert into STOCK values (1,'Apple',100)"
cur.execute(sql)
sql = "insert into STOCK values (2,'Mango',35)"
cur.execute(sql)
sql = "insert into STOCK values (3,'Grapes',40)"
cur.execute(sql)
sql = "insert into STOCK values (4,'Orange',80)"
cur.execute(sql)
conn.commit()
print("Inserted Successfully")
cur.close()
conn.close()
