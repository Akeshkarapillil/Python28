s1 = 'Welcome to Python '
print(s1)
print(s1[0])
print(s1[1:4])
print(s1[:5])
print(s1*3)

a = int(input('Enter Ist No: '))
b = int(input('Enter IInd No: '))
print("%d + %d = %d" % (a,b,a+b))

n = int(input('Enter No: '))
i = 1
while(i<=10):
	print("%5d X %-5d = %5d" % (i,n,i*n))
	i+=1