name = input('Enter Name: ')
n = float(input('Enter no: '))
print('Hi '+name+' UR No is : '+str(n))