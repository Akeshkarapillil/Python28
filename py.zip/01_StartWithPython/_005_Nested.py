#nested loops
import sys
n = int(input('Enter Level: '))
i = 1
while(i<=n):
	j=1
	while(j<=i):
		sys.stdout.write('* ')
		j+=1
	i+=1
	print()


#nested loops
import sys
n = int(input('Enter Level: '))

for i in range(1,n+1):
	for j in range(1,i+1):
		sys.stdout.write('* ')
	print()
	
for i in range(n+1,0,-1):
	for j in range(1,i+1):
		sys.stdout.write('* ')
	print()