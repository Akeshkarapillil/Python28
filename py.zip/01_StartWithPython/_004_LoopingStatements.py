import sys
n = int(input('Enter No'))
i = 1
while(i<=n):
	sys.stdout.write(str(i)+' ')
	i+=1

print('\nPrinting in reverse')

while(i>1):
	i-=1
	sys.stdout.write(str(i)+' ')
else: print('\nReached '+str(i)+' so terminating...')

a = int(input('Enter Start no: '))
b = int(input('Enter End no: '))
for i in range(a,b+1):
	print(i)