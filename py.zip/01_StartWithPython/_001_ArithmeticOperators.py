#!python
print ("Welcome to python !")
print ('Welcome to python !')
print (20+5)
print ("20 + 5 = "+str(20+5))
a = 10
b = 5
print(str(a)+' + '+str(b)+' = '+str(a+b))
a,b = 50,25
print(str(a)+' + '+str(b)+' = '+str(a+b))
print(a,' + ',b,' = ',a+b)
#del a
print('\n\ta = '+str(a))
print(5/2)
print(5%2)
print(int(5/2))
print('====================')
print(5+2)
print(5*2)
print(5**2)
print(5//2)