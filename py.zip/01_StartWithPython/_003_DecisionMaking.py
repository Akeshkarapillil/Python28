n = int(input("Enter No: "))
"""
if(n%2==0):
	print("Even no.")
if(n%2!=0):
	print("Odd no.")
"""

'''
if(n==0): print("neither Even nor Odd")
else:
	if(n%2==0): print("Even")
	else : print("Odd")
'''

if(n != 0):
    print('Ur entered non-zero value')
else:
    print('Ur entered zero')

if(n == 0):
    print('neither Even nor Odd')
elif(n % 2 == 0):
    print('Even')
else:
    print('Odd')

y = int(input('Enter Year: '))
if((y%4==0 and y%100!=0) or y%400==0): print('Leap Year')
else: print('not Leap Year')