#Dictionary
dic1 = {'a':'Apple','b':'Bat','c':'Cat','d':'Dog'}
print(dic1)
print(dic1['b'])
dic1['b'] = 'Ball'
print(dic1['b'])
del dic1['d']
print(dic1)
#del dic1
print(dic1.items())
print(dic1.keys())
print(dic1.values())
dic1.clear()
print(dic1)