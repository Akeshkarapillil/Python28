import sys
ar = [[1,2,3],[4,5,6],[7,8,9],[10,11,12]]
#print(ar)

ar[1][1] = 100

print('using for..')
for r in ar:
	for c in r:
		sys.stdout.write('%5i' % (c))
	print()

print('using while..')

#print(len(ar)) # row size
#print(len(ar[0])) # col size
i=0
while(i<len(ar)):
	j=0
	while(j<len(ar[i])):
		sys.stdout.write('%5i' % (ar[i][j]))
		j+=1
	print()
	i+=1