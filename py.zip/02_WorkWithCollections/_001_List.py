lst_1 = ['red', 'green', 'blue', 'violet', 'magenta', 'yellow']
print(lst_1)
print(lst_1[0])
print(lst_1[1:4])
print(lst_1[:4])
del lst_1[2]
print(lst_1)
lst_1[2] = 'cyan'
print(lst_1)
print(lst_1[-1])

for cols in lst_1:
    print(cols)

lst_2 = ['pen', 'pencil', 'book']
lst_3 = lst_1 + lst_2
print(lst_3)
