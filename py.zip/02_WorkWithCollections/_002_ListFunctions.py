lst_1 = ['one','two','three','four','one']
lst_2 = [22,10,5,99,12]

print(len(lst_1))
print(max(lst_2))
print(min(lst_2))

print(lst_1)
lst_1.append('five')
print(lst_1)
print(lst_1.count('one'))
lst_1.insert(2,'six')
print(lst_1)
print(lst_1.pop())
print(lst_1)
lst_1.remove('one')
lst_1.remove('one')
#lst_1.sort()
print(lst_1)
lst_1.reverse()
print(lst_1)
lst_2.sort()
#lst_2.reverse()
print(lst_2)

lst_3 = lst_1*2
print(lst_3)

if('three' in lst_1): print('found ! three')
else: print('not found ! three')

if(5 in lst_2): print('found ! 5')
else: print('not found ! 5')