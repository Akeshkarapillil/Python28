import sys

m = int(input("Enter Row Size : "))
n = int(input("Enter Col Size : "))
lst = []
for i in range(0,m):
	tmp = []
	for j in range(0,n):
		x =  int(input("Enter (%d,%d) element : " % (i+1,j+1)))
		tmp.append(x)
	lst.append(tmp)
#print(len(lst[0]))
for i in lst:
	tmp = []
	for j in i:
		sys.stdout.write("%5d" % j)
	print('')