# tuples read only list
tup1 = ('red','green','blue','orange','violet')
print(tup1)
print(tup1[0])
print(tup1[1:4])
print(tup1[:4])
#tup1[1] = 'gray' # Will create error
#del tup1
#print(tup1)
