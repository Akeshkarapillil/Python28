import sys

n = int(input("Enter Level: "))
lst = []

for i in range(0,n):
	x =  int(input("Enter no %d): " % (i+1)))
	lst.append(x)

for i in range(0,n):
	sys.stdout.write("%5d" % lst[i])