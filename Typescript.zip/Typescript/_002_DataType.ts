// bool
let a: boolean = true;
console.log(a);
console.log(typeof(a))

//number
let b: number = 0b000111;
console.log(b);
console.log(typeof(b))

//Array
// let c: string[] = ["asd"]

let s: any = "Abc";

let n: string = (<string> s)