// var uname;
// uname = "Ammu";
// console.log(uname)
// var uname = "Ammu";
// console.log(uname);
// var uname: string;
// uname = "123";
// console.log(uname);
// var uname: boolean = true;
// console.log(uname);
