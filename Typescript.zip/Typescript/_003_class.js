// class MyClass{
//     name: string;
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//     constructor(name: string){
//         this.name = name;
//     }
//     get_name(){
//         return `Hello ${this.name}`;
//     }
// }
// let myclass = new MyClass("Manu");
// console.log(myclass.name);
// console.log(myclass.get_name());
var BaseClass = /** @class */ (function () {
    function BaseClass(x) {
        this.i = x;
    }
    BaseClass.prototype.get_value_i = function () {
        return this.i;
    };
    return BaseClass;
}());
var DerivedClass = /** @class */ (function (_super) {
    __extends(DerivedClass, _super);
    function DerivedClass(x, y) {
        var _this = _super.call(this, x) || this;
        _this.j = y;
        return _this;
    }
    DerivedClass.prototype.get_value_j = function () {
        this.i;
        return this.j;
    };
    DerivedClass.prototype.get_data = function () {
        this.i;
    };
    return DerivedClass;
}(BaseClass));
var obj = new DerivedClass(12, 13);
console.log(obj.j);
console.log(obj.get_value_i());
console.log(obj.get_value_j());
