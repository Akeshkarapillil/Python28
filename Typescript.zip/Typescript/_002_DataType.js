// bool
var a = true;
console.log(a);
console.log(typeof (a));
//number
var b = 123456;
console.log(b);
console.log(typeof (b));
