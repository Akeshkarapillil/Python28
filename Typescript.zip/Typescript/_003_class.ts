
// class MyClass{
//     name: string;

//     constructor(name: string){
//         this.name = name;
//     }

//     get_name(){
//         return `Hello ${this.name}`;
//     }
// }

// let myclass = new MyClass("Manu");
// console.log(myclass.name);
// console.log(myclass.get_name());


class BaseClass{
    protected i: number;

    constructor(x: number){
        this.i = x;
    }

    public get_value_i(){
        return this.i;
    }
}

class DerivedClass extends BaseClass{
    j: number;

    constructor(x: number, y: number){
        super(x);
        this.j = y;
    }

    public get_value_j(){
        this.i;
        return this.j;
    }

    protected get_data(){
        this.i
    }
}

let obj = new DerivedClass(12, 13);
console.log(obj.j);
console.log(obj.get_value_i());
console.log(obj.get_value_j());




