
interface MyInterface{
    name: string;
    age: number;

    get_detail(): string
}


class MyClass implements MyInterface{

    name: string;
    age: number;
    address: string;

    get_detail(){
        return ""
    }



}