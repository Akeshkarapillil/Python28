import requests
from bs4 import BeautifulSoup

url = "https://www.flipkart.com/search?q=ihone14+pro+max&sid=tyy%2C4io&as=on&as-show=on&otracker=AS_QueryStore_HistoryAutoSuggest_1_1_na_na_na&otracker1=AS_QueryStore_HistoryAutoSuggest_1_1_na_na_na&as-pos=1&as-type=HISTORY&suggestionId=ihone14+pro+max%7CMobiles&requestId=7011aef6-2be1-4c66-89df-eb40c78f82ce&as-searchtext=i%5B"


page = requests.get(url).content

soup = BeautifulSoup(page, 'html.parser')

# print(soup.prettify())
print(soup.title.text)