# pip install beautifulsoup4
from bs4 import BeautifulSoup

html = '''
<html>
    <head>
        <title>My WebSite</title>
    </head>
    <body>
        <h1 class="head primary red" id="head">Heading</h1>
        <hr>
        <p>
            sdfsgsg
            dfgdgdfgdfg
            dfgdgdfgdf
            fdgdfg
        </p>
        <p>
            fdbgdfg
        </p>
    </body>
</html>
'''

soup = BeautifulSoup(html, 'html.parser')

# print(soup)
# print(soup.title)
# print(soup.h1.text)
# print(soup.h1.attrs)

# print(soup.find_all('p'))
# all_p = soup.find_all('p')

# print(all_p[0].text)
# for p in all_p:
#     print(p.text)

