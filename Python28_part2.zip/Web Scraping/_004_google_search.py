# pip install googlesearch-python

from googlesearch import search
import requests
from bs4 import BeautifulSoup


keyword = input("Enter A keyword:")

result = search(keyword, num_results=5)

# print(result)
for res in result:
    # print(res)
    page = requests.get(res).content
    soup = BeautifulSoup(page, 'html.parser')
    print(soup.title.text)