'''

Software Testing
----------------
    Software Testing is a process of testing the software that is 
    developed.
    There are different types of testing:
        1. Unit Testing
        2. Integration Testing
        3. System Testing
        4. Acceptance Testing
        5. Manual Testing
        6. Functional Testing
        7. Performance Testing
        8. Load Testing
        9. Stress Testing
    
    Unit Testing
    -------------
        Unit Testing is the process of testing the functionality of
        a single module or a single class.
        The application under test is divided into smaller units and
        each unit is tested independently.

        in python, we can use unittest module to test the unit.
        unittest module is a python module that provides a testing
        framework for python programs.
        unittest is a High Level Testing Framework.


    unittest module

    Test Fixtures
    --------------
        Test Fixtures is a set of pre-defined code that is used to
        setup and tear down the testing environment.

    Test Suite
    ----------
        Test Suite is a collection of test cases that are related to
        a particular module or a class.

    Test Case
    ---------
        Test Case is a single test that is used to test a particular
        functionality of a module or a class.
        Test Case is a subclass of unittest.TestCase.
    
    Test Runner
    -----------
        Test Runner is a class that is used to run the test cases.

    Test Result
    -----------
        Test Result is a class that is used to store the results of
        the test cases.



'''

import unittest

class MyTest(unittest.TestCase):

    def test_asd(self):
        self.assertEqual(1, 2, "1 is not equal to 1")

if __name__ == "__main__":
    unittest.main()