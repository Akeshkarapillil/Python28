$(function(){
    // $.get('http://beyont.in/angularapi/getuser.php', {'key', 'value'} function(dt){
    // $.get('http://beyont.in/angularapi/getuser.php', function(dt){
    //     dt = JSON.parse(dt);
    //     // console.log(dt);
    //     data = dt.data;
    //     data = data.slice(0, 10);
    //     // console.log(data);
    //     data.forEach(element => {
    //         // console.log(element.name);
    //         $('#cnt').append('<li>'+element.name+'</li>');
    //     });
    // });
    // data = {
    //     'name': 'beyont',
    //     'email': 'beyont@gmail.com',
    //     'password': '123456'
    // }
    // $.post('http://beyont.in/angularapi/registration.php', data, function(res){
    //     console.log(res);
    // });

    // $.ajax({
    //     url: 'http://beyont.in/angularapi/getuser.php',
    //     type: 'GET',
    //     data: {'email': ''},
    //     dataType: 'json',
    //     success: function(dt){
    //         console.log(dt);
    //     },
    //     error: function(err){
    //         console.log(err);
    //     },
    //     complete: function(com){
    //         console.log(com);
    //     },
    //     beforeSend: function(bef){
    //         console.log(bef);
    //     },
    //     timeout: 3000,
    //     async: true,
    //     cache: false,
    //     contentType: 'application/x-www-form-urlencoded',
    //     processData: true,
    //     crossDomain: true
    // });
});