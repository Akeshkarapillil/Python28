// JQuery Syntax: $(selector).action();

// $(function(){
//     alert("Hello World!");
// })

// or

// $(document).ready(function(){
//     alert("Hello World!");
// });


/*

JQuery selectors

    $("element")
    $("#id")
    $(".class")
    $("*")
    $("[attribute]")
    $("[attribute=value]")

JQuery events

    click
    dblclick
    mouseover
    mouseout
    mouseenter
    mouseleave
    mousedown
    mouseup
    keydown
    keyup
    keypress
    focus
    blur
    change
    submit
    load
    etc..

*/

// document.getElementById("id").style.backgroundColor = "red";

// $(function(){
//     // $("*").css("color", "red");
//     // $("p").css("color", "red");
//     // $("#p1").css("color", "red");
//     // $(".d1").css("color", "red");
//     // $("[data]").css("color", "blue");
//     // $("[data='asd']").css("color", "red");
// });


// function say_hi(){
//     alert("Hi");
// }

// $(function(){
//     $("h2").dblclick(function(){
//         alert("Hi");
//     })
// })


// JQuery Events Effects

/*

hide
show
toggle

fadeIn
fadeOut
fadeToggle

slideDown
slideUp
slideToggle


*/

$(document).ready(function(){
    // $("#btn_hide").click(function(){
    //     $("p").hide('slow', function(){
    //         alert("Done");
    //     });
    // });

    // $("#btn_show").click(function(){
    //     $("div").hide(1000).show(1000).slideUp().slideDown();
    // });

    // $("#btn_toggle").click(function(){
    //     $("p").toggle();
    // });

    // $("#btn_fadein").click(function(){
    //     $("div").fadeIn();
    // });
    // $("#btn_fadeout").click(function(){
    //     $("div").fadeOut();
    // });
    // $("#btn_fadeToggle").click(function(){
    //     $("div").fadeToggle();
    // });
    // $("#btn_slideDown").click(function(){
    //     $("div").slideDown();
    // });
    // $("#btn_slideUp").click(function(){
    //     $("div").slideUp();
    // });
    // $("#btn_slideToggle").click(function(){
    //     $("div").slideToggle();
    // });

    // $("#btn_animate").click(function(){
    //     $("div").animate({
    //         left: "500px",
    //         backgroundColor: "red",
    //         borderRadius: "50%"
    //     }, 3000, function(){
    //         $("div").hide();
    //     });
    //     // $(this).animate({
    //     //     borderRadius: "10px",
    //     // }, 1000)
    // });

    // $("#btn_stop").click(function(){
    //     $("div").stop();
    // });
    
    $("#btn_get").click(function(){
        // alert($("#head").text());
        // $("#head").text("Hello World!");
        // alert($("#head").html());
        // $("#head").html("<h1>Hello World!</h1>");
        alert($("#txt").val());
    })

    $("#btn_set").click(function(){
        $("#txt").val("Hello World!");
    })


});


/*

CallBack Function
chainning




*/