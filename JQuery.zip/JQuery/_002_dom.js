$(function(){
    // $('#cnt').text('<b>Hello World</b>');

    // c = '';

    // for(var i = 0; i < 8; i++){
    //     for(var j = 0; j < 8; j++){
    //         if((i + j) % 2 == 0) c += '<div class="d d1"></div>';
    //         else c += '<div class="d d2"></div>';
    //     }
    //     c += '<br>';
    // }

    // $('#cnt').html(c);


    // $('#list').prepend('<li>Item -1</li>');
    // $('#list').append('<li>Item 3</li>');

    // $('#list').before("<h1>Before</h1>");
    // $('#list').after("<h1>After</h1>");

    // $('#list').empty();
    // $('#list').remove();

    // $('li').click(function(){
    //     $('li').removeClass('active');
    //     $(this).addClass('active')
    // })

    // $('ul').attr('class', 'list');

    // alert($('ul').attr('class'));


    // $('#p1').css({color: 'red', background: '#ccc'});

    

})