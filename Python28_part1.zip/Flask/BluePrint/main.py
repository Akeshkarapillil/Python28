from flask import Flask, render_template
from admin.admin import admin_bp

app = Flask(__name__)
# app.register_blueprint(admin, url_prefix="")
app.register_blueprint(admin_bp, url_prefix="/admin")
# app.register_blueprint(admin, url_prefix="/staff")


if __name__ == "__main__":
    app.run(debug=True)