from flask import Blueprint, render_template

admin_bp = Blueprint("admin_bp", __name__, static_folder="static", template_folder="templates")

@admin_bp.route('/home/')
@admin_bp.route('/')
def index():
    return render_template('index.html')
