from flask import Flask
from admin.admin import admin
from user.user import user

app = Flask(__name__)

app.register_blueprint(user, url_prefix="")
app.register_blueprint(admin, url_prefix="/admin")

if __name__ == '__main__':
    app.run()