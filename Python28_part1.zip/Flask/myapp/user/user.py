from flask import Blueprint, render_template

user = Blueprint('user', __name__, static_folder='static', template_folder='templates')


@user.route('/home')
@user.route('/')
def index():
    return render_template('user/index.html')



@user.route('/contact')
def about():
    return render_template('user/about.html')
