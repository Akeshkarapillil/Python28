from flask import Flask, render_template,url_for, redirect

app = Flask(__name__)

@app.route('/')
def index():
    context = {
        'title': 'Index Page' 
    }
    context['name'] = "Sarath"
    context['age'] = 25
    context['colors'] = ['red', 'green', 'blue', 'black']
    return redirect(url_for('home', id=12))
    # return render_template('index.html', data = context)

@app.route('/user/home/index/<int:id>')
def home(id):
    context = {
        'id': id
    }
    return render_template('home.html', context=context)


if __name__ == '__main__':
    app.run(debug=True)


'''
{{}}

{% %}


'''