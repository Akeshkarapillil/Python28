from flask import Flask

app = Flask(__name__)

@app.route('/index/')
def index():
    return "<h1>First Flask App Hello</h1>"

@app.route('/about')
def about():
    return "<h1>About Page</h1>"

@app.route('/movie/<id>/')
def movie(id):
    return f"<h1> Movie ID : {id}</h1>"

if __name__ == '__main__':
    app.run(debug=True)

'''
-> Home Page
/about/ -> About
/contact/ - >contact


/check/6 -> odd / even
/add/4/6  -> 10
users = [
    {id: 12, name: sdfsd, place: sdfs, ...},
    ..
    ..
]
'''