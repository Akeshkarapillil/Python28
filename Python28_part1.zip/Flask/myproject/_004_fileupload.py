from fileinput import filename
import os
from flask import Flask, render_template,url_for, redirect, request
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'qwertyyuui'
app.config['UPLOAD_FOLDER'] = '.\\static\\uploads'

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'yourId@gmail.com'
app.config['MAIL_PASSWORD'] = '*****'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

mail = Mail(app)


@app.route('/', methods=['GET', 'POST'])
def file_upload():
    if request.method == 'GET':
        return render_template('user/fileupload.html')
    elif request.method == 'POST':
        title = request.form['title']
        file = request.files['file']
        fn = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], fn))
        return redirect(url_for('view_file', filename=fn))

@app.route('/view/<filename>')
def view_file(filename):
    return render_template('user/view_file.html', file=filename)

@app.route('/email/')
def email_send():
    msg = Message()
    msg.subject = 'Your subject'
    msg.recipients = ['list']
    msg.sender = app.config['MAIL_USERNAME']
    msg.body = 'Your mail body content'
    mail.send(msg)
    return 'ok'



if __name__ == '__main__':
    app.run(debug=True)
