import sqlite3


class DbConnect:

    def __init__(self):
        self.__conn = sqlite3.connect('db/mydb.db')
        self.__cursor = self.__conn.cursor()
        self.__cursor.execute('CREATE TABLE IF NOT EXISTS reg (id INTEGER, firstname TEXT,lastname TEXT, email TEXT, phone INTEGER, password TEXT, PRIMARY KEY(id AUTOINCREMENT))')

    def __del__(self):
        self.__cursor.close()
        self.__conn.close()

    def set_data(self, sql, args=None):
        try:
            if args is None:
                self.__cursor.execute(sql)
            else:
                self.__cursor.execute(sql, args)
            self.__conn.commit()
            return True
        except Exception as e:
            print(e)
            return False
    
    def get_data(self, sql, args=None):
        try:
            if args is None:
                self.__cursor.execute(sql)
            else:
                self.__cursor.execute(sql, args)
            return self.__cursor.fetchall()
        except Exception as e:
            print(e)
            return None
