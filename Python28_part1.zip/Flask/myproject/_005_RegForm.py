from flask_wtf import Form
# from wtforms import TextAreaField, IntegerField, BooleanField, RadioField, SelectField
from wtforms import *


class RegistrationForm(Form):
    first_name = StringField('First Name', validators=[validators.Length(min=3, max=15)])
    last_name = StringField('Last Name')
    email = EmailField('Email ID', validators=[validators.DataRequired()])
    phone = IntegerField('Phone Number')
    password = PasswordField('Password', validators=[validators.DataRequired(), validators.EqualTo('confirm', 'Password must match!')])
    confirm = PasswordField('Confirm Password')
    terms = BooleanField("T&C")


