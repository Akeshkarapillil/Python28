from flask import Flask, render_template,url_for, redirect, request, abort, flash, make_response, session

app = Flask(__name__)
app.secret_key = 'qwertyyuui'

@app.route('/', methods=['GET', 'POST'])
def create_cookie():
    if request.method == 'GET':
        return render_template('user/cookies.html')
    elif request.method == 'POST':
        name = request.form.get('name')
        resp = make_response(render_template('user/cookies.html'))
        resp.set_cookie('name', name, 60*60)
        return resp

@app.route('/read/')
def read_cookie():
    name = request.cookies.get('name')
    return f'Name : {name}'


@app.route('/session/',  methods=['GET', 'POST'])
def create_session():
    if request.method == 'GET':
        return render_template('user/session.html')
    elif request.method == 'POST':
        name = request.form.get('name')
        session['name'] = name
        return redirect(url_for('create_session'))

@app.route('/read/session/')
def read_session():
    name = session.get('name')
    return f'Name : {name}'


if __name__ == '__main__':
    app.run(debug=True)
