from flask import Flask, render_template,url_for, redirect, request
from _005_RegForm import RegistrationForm
from dbconnect import DbConnect

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def registration():
    form = RegistrationForm(request.form)
    if request.method == 'GET':
        return render_template('registration.html', form=form)
    elif request.method == 'POST':
        if form.validate():
            fname = form.first_name.data
            lname = form.last_name.data
            email = form.email.data
            phone = form.phone.data
            password = form.password.data
            db = DbConnect()
            sql = f"INSERT INTO reg(firstname, lastname, email, phone, password) VALUES(?,?,?,?,?)"
            res = db.set_data(sql, (fname, lname, email, phone, password))
            if res:
                return 'Inserted...'
            else:
                return 'Not Inserted..'
        else:
            return render_template('registration.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)
