// alert('Js works!')


var n = prompt("Enter your name :")
var p = /^[A-Z]{1}+[a-z]{2,10}$/
console.log(p.test(n))