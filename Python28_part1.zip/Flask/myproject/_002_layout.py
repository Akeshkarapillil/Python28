from flask import Flask, render_template,url_for, redirect, request, abort, flash

app = Flask(__name__)
app.secret_key = 'qwertyyuui'

@app.route('/')
def index():
    return render_template('user/index.html')

@app.route('/about/')
def about():
    return render_template('user/about.html')
    # return redirect('/aboutus/', 301)

@app.route('/aboutus/')
def aboutus():
    return "<h1>About Us</h1>"

@app.route('/contact/')
def contact():
    return abort(403)
    # return render_template('user/contact.html')

@app.route('/signup/', methods=['GET','POST'])
def register():
    if request.method == 'GET':
        return render_template('user/register.html')
    elif request.method == 'POST':
        fname = request.form.get('firstname')
        lname = request.form.get('lastname')
        email = request.form.get('email')
        password = request.form.get('password')

        # return f'First Name : {fname} </br>Last Name: {lname}<br>Email : {email}</br>Password: {password}'
        flash('Account created', 'success')
        flash('Account created Error', 'danger')
        return redirect(url_for('register'))

# @app.route('/signup/save/', methods=['GET','POST'])
# def save():
    # fname = request.args.get('firstname')
    # lname = request.args.get('lastname')
    # email = request.args.get('email')
    # password = request.args.get('password')
    # fname = request.form.get('firstname')
    # lname = request.form.get('lastname')
    # email = request.form.get('email')
    # password = request.form.get('password')
    # return f'First Name : {fname} </br>Last Name: {lname}<br>Email : {email}</br>Password: {password}'


if __name__ == '__main__':
    app.run(debug=True)
