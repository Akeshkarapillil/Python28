$(function(){
    $('button').click(function(){
        email = $('#email').val();
        data = {
            'email': email,
            'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val()
        }
        $.post('/myapp2/checkemail/', data, function(res){
            // if(res.status){
            //     $('#email').css({'borderColor':'green'})
            //     // $('#email').after('<span style="color:green">Available</span>')
            // }
            // else{
            //     $('#email').css({'borderColor':'red'})
            // }
            console.log(res.data)
        })
    })
})