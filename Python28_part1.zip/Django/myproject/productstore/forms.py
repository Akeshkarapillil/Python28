from django import forms
from .models import Product, ProductExtra, FileModel

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        exclude = '__all__'
        widgets = {
            'name': forms.TextInput(
                attrs={
                    'class': 'form-control'
                }
            ),
        }


class ProductExtraForm(forms.ModelForm):
    """Form definition for ProductExtra."""

    class Meta:
        """Meta definition for ProductExtraform."""

        model = ProductExtra
        fields = '__all__'

class FileModelForm(forms.ModelForm):
    """Form definition for FileModel."""

    class Meta:
        """Meta definition for FileModelform."""

        model = FileModel
        fields = '__all__'

