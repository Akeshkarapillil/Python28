from django.http import HttpResponse
from django.shortcuts import redirect, render
from .forms import ProductForm, ProductExtraForm, Product, ProductExtra, FileModelForm
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView
from django.urls import reverse_lazy

from .models import FileModel

# Create your views here.
# Class-Based View

class ProductListView(ListView):
    model = Product
    template_name = 'productstore/product_list.html'
    context_object_name = 'products'
    paginate_by = 10

    def get_queryset(self):
        queryset = Product.objects.all()
        return queryset


class ProductCreateView(CreateView):
    model = Product
    template_name = 'productstore/product_create.html'
    form_class = ProductForm
    success_url = reverse_lazy('productstore_list')

class ProductUpdateView(UpdateView):
    model = Product
    template_name = 'productstore/product_create.html'
    form_class = ProductForm
    # pk_url_kwarg = 'pid'
    success_url = reverse_lazy('productstore_list')

class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'productstore/product_delete.html'
    # pk_url_kwarg = 'pid'
    success_url = reverse_lazy('productstore_list')


def save_file(request):
    if request.method == 'GET':
        return render(request, 'productstore/file.html', {'form': FileModelForm()})
    elif request.method == 'POST':
        # title = request.POST['title']
        # file = request.FILES['file']
        # print(title, file.filename)
        # obj = FileModel(title=title, file=file)
        # obj.save()
        file = FileModelForm(data=request.POST, files=request.FILES)
        file.save()

        return HttpResponse("Saved...")


def view_file(request):
    if request.method == 'GET':
        return render(request, 'productstore/file_view.html', {'files': FileModel.objects.all()})

