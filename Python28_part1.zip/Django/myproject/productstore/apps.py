from django.apps import AppConfig


class ProductstoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'productstore'
