from django.urls import path
from .views import *

urlpatterns = [
    path('list/', ProductListView.as_view(), name='productstore_list'),
    path('create/', ProductCreateView.as_view(), name='productstore_create'),
    path('update/<int:pk>', ProductUpdateView.as_view(), name='productstore_update'),
    path('delete/<int:pk>', ProductDeleteView.as_view(), name='productstore_delete'),

    path('file/', save_file, name='productstore_file'),
    path('view/', view_file, name='productstore_view'),

]