from django.db import models

# Create your models here.
class ProductExtra(models.Model):
    expiery = models.DateField()
    more_description = models.TextField(
        max_length=3000
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Product(models.Model):
    BRANDS = (
        ('nike', 'Nike'),
        ('apple', 'Apple'),
        ('samsung', 'Samsung')
    )

    name = models.CharField(
        verbose_name='Product Name',
        max_length=50,
    )
    slug = models.CharField(
        verbose_name='Slug',
        max_length=50,
        unique=True,
    )
    description = models.TextField(
        verbose_name='Product Description',
        max_length=500,
        null=True,
        blank=True
    )
    stock = models.IntegerField(
        verbose_name='Stock',
        default=0,
    )
    brand = models.CharField(
        verbose_name='Product Brand',
        max_length=50,
        choices=BRANDS
    )
    status = models.BooleanField(
        verbose_name='Ststus',
        default=True
    )


class FileModel(models.Model):
    title = models.CharField(verbose_name='Title', max_length=100)
    file = models.FileField(
        verbose_name='File',
        upload_to='Uploads',
        max_length=300,
    )

    def __str__(self):
        return self.title



