from django.db import models

# Create your models here.

class Todo(models.Model):
    todo_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50, verbose_name='Todo Title', blank=False, null=False)
    description = models.TextField(verbose_name='Todo Description', blank=True, null=True)
    completed = models.BooleanField(default=False, verbose_name='Completed')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title