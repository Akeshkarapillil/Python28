from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='myapp_home'),
    path('create/', create_todo, name='myapp_create'),
    path('delete/<int:todo_id>', delete_todo, name='myapp_delete'),
    path('update/<int:todo_id>', update_todo, name='myapp_update'),
    path('form/create/', create_todo_using_form, name='myapp_create_using_form'),
    path('modelform/create/', create_todo_using_modelform, name='myapp_using_modelform'),
    path('modelform/update/<int:todo_id>', update_todo_using_modelform, name='myapp_using_modelform_update')
]