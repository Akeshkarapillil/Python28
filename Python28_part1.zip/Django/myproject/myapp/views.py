from django.shortcuts import redirect, render, HttpResponse
from .models import Todo
from .forms import TodoForm, TodoModelForm


# Create your views here.
def home(request):
    context = {}
    context['todos'] = Todo.objects.all()
    # context['todos'] = Todo.objects.filter(completed=False)
    return render(request, 'myapp/home.html', context)


def create_todo(request):
    if request.method == 'GET':
        return render(request, 'myapp/create.html')
    elif request.method == 'POST':
        title = request.POST['title']
        description = request.POST['description']
        # Todo.objects.create(title=title, description=description)
        todo = Todo(title=title, description=description)
        todo.save()
        return HttpResponse("Inserted...")


def delete_todo(request, todo_id):
    todo = Todo.objects.get(todo_id=todo_id)
    todo.delete()
    return redirect('myapp_home')

def update_todo(request, todo_id):
    todo = Todo.objects.get(pk=todo_id)
    if request.method == 'GET':
        context = {}
        context['form'] = TodoForm(initial={'title': todo.title, 'description': todo.description, 'status':todo.completed})
        return render(request, 'myapp/update.html', context)
    elif request.method == 'POST':
        title = request.POST['title']
        description = request.POST['description']
        todo.title = title
        todo.description = description
        todo.save()
        return redirect('myapp_home')


# ---------------------------------------------------------------------

def create_todo_using_form(request):
    if request.method == 'GET':
        return render(request, 'myapp/create_using_form.html', context={'form': TodoForm()})
    elif request.method == 'POST':
        todo_form = TodoForm(request.POST)
        if todo_form.is_valid():
            title = todo_form.cleaned_data['title']
            description = todo_form.cleaned_data['description']
            status = todo_form.cleaned_data['status']
            # return HttpResponse(title+description+str(status))
            Todo.objects.create(title=title, description=description, completed=status)
            return redirect('myapp_home')
        else:
            return render(request, 'myapp/create_using_form.html', context={'form': todo_form})


def create_todo_using_modelform(request):
    if request.method == 'GET':
        return render(request, 'myapp/create_using_modelform.html', context={'form': TodoModelForm()})
    elif request.method == 'POST':
        todo = TodoModelForm(request.POST)
        if todo.is_valid():
            todo.save()
            return redirect('myapp_home')
        else:
            return render(request, 'myapp/create_using_form.html', context={'form': todo})


def update_todo_using_modelform(request, todo_id):
    todo = Todo.objects.get(pk=todo_id)
    if request.method == 'GET':
        return render(request, 'myapp/create_using_modelform.html', context={'form': TodoModelForm(instance=todo)})
    elif request.method == 'POST':
        todo = TodoModelForm(request.POST, instance=todo)
        if todo.is_valid():
            todo.save()
            return redirect('myapp_home')
        else:
            return render(request, 'myapp/create_using_form.html', context={'form': todo})