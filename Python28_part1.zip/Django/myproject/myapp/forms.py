from django import forms
from .models import Todo


class TodoForm(forms.Form):
    title = forms.CharField(
        label='Todo Title', 
        min_length=3, 
        max_length=50,
        required=True
    )
    description = forms.CharField(
        label='Description',
        widget=forms.Textarea(attrs={
            'row':4,
            'col':30
        })
    )
    status = forms.BooleanField(
        required=False
    )


class TodoModelForm(forms.ModelForm):

    class Meta:
        model = Todo
        # fields = ['title', 'description']
        fields = '__all__'



