from django.http import HttpResponse
from django.shortcuts import redirect, render
from .forms import UserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail

# Create your views here.
def login_view(request):
    if request.method == 'GET':
        return render(request, 'accounts/login.html')
    elif request.method == 'POST':
        user = authenticate(request, username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            login(request, user)
            if user.is_superuser:
                return redirect('/admin/')
            else:
                return redirect('user_home')
        else:
            return render(request, 'accounts/login.html', {'error': 'Invalid Username / Password'})

def register_view(request):
    if request.method == 'GET':
        context = {}
        context['form'] = UserForm()
        return render(request, 'accounts/register.html', context)
    elif request.method == 'POST':
        user = UserForm(request.POST)
        if user.is_valid():
            obj = user.save(commit=False)
            obj.user_type = 'cutomer'
            obj.set_password(user.cleaned_data['password'])
            obj.save()
            send_mail("Account Creation Confirmation", "Account created on your email address", from_email='quest.project.akesh@gmail.com', recipient_list=[user.cleaned_data['email']])
            return redirect('accounts_register')
        else:
            context = {}
            context['form'] = user
            return render(request, 'accounts/register.html', context)


# @login_required()
def home(request):
    if request.method == 'GET':
        # context = {}
        # context['username'] = request.user.username
        return render(request, 'accounts/home.html')

@login_required()
def profile(request):
    if request.method == 'GET':
        context = {}
        context['form'] = UserForm(instance=request.user)
        return render(request, 'accounts/register.html', context)
    elif request.method == 'POST':
        user = UserForm(data=request.POST, instance=request.user)
        if user.is_valid():
            user.save()
            return redirect('accounts_register')
        else:
            context = {}
            context['form'] = user
            return render(request, 'accounts/register.html', context)


def logout_view(request):
    logout(request)
    return redirect('accounts_login')