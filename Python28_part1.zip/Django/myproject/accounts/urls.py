from django.urls import path
from .views import *

urlpatterns = [
    path('login/', login_view, name='accounts_login'),
    path('register/', register_view, name='accounts_register'),
    path('home/', home, name='user_home'),
    path('profile/', profile, name="user_profile"),
    path('logout/', logout_view, name='accounts_logout'),
]