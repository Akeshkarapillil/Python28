from unicodedata import name
from django.urls import path
from .views import *


urlpatterns = [
    path('cookie/create/', create_cookie, name='myapp2_create_cookie'),
    path('cookie/read/', read_cookie, name="myapp_read_cookie"),
    path('session/create/', create_session, name='myapp_session'),
    path('session/read/', read_session, name='myapp_read_session'),
    path('refresh/', refresh, name='myapp_refresh'),
    path('account/', create_account, name='myapp2_account'),
    path('checkemail/', checkemail, name='myapp2_checkemail'),
]