from datetime import datetime
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from accounts.models import User

# Create your views here.

def create_cookie(request):
    if request.method == 'GET':
        return render(request,'myapp2/create.html')
    elif request.method == 'POST':
        uname = request.POST['uname']
        date = datetime.now()
        resp = render(request, 'myapp2/create.html', {'uname': uname, 'date': date})
        resp.set_cookie('uanme', uname, 60)
        resp.set_cookie('date', date)
        return resp


def read_cookie(request):
    uname = ''
    date = ''
    if request.COOKIES.get('uanme'):
        uname = request.COOKIES['uanme']
        date = request.COOKIES['date']
    return HttpResponse(f"Uname : {uname} <br> Date: {date}")

def create_session(request):
    if request.method == 'GET':
        return render(request,'myapp2/create.html')
    elif request.method == 'POST':
       uname = request.POST['uname']
       request.session['uname'] = uname
       request.session.set_expiry(60)
       return redirect('myapp_read_session')

def read_session(request):
    uname = ''
    if 'uname' in request.session:
        uname = request.session['uname']
    return HttpResponse(f"Uname : {uname}")

def refresh(request):
    count = 0
    if request.COOKIES.get('count'):
        count = int(request.COOKIES['count'])
    count += 1
    resp = render(request, 'myapp2/count.html', {'count': count})
    resp.set_cookie('count', str(count))
    return resp

def create_account(request):
    return render(request, 'myapp2/ajax.html')

def checkemail(request):
    # if request.method == 'POST':
    email = request.GET.get('email')
    obj = list(User.objects.all())
    status = False
    if len(obj) < 1:
        status = True
    return JsonResponse({'data': status})






