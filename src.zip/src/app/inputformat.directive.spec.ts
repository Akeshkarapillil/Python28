import { InputformatDirective } from './inputformat.directive';

describe('InputformatDirective', () => {
  it('should create an instance', () => {
    const directive = new InputformatDirective();
    expect(directive).toBeTruthy();
  });
});
