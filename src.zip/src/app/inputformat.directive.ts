import { Directive, HostListener, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[Inputformat]'
})
export class InputformatDirective {

  @Input('Inputformat') format = 'lowercase' 

  _er: ElementRef;
  constructor(er: ElementRef) { 
    this._er = er;
  }

  // @HostListener ('focus') onFocus(){
  //   console.log("on focus change");
  // }

  @HostListener ('blur') onBlur(){
    let val: string = this._er.nativeElement.value;
    if(this.format == 'lowercase'){
      this._er.nativeElement.value = val.toLowerCase();
    }
    else{
      this._er.nativeElement.value = val.toUpperCase();
    }
  }

}
