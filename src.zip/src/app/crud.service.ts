import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class CrudService {

  constructor(private http: HttpClient) { }

  register(params: any){
    // console.log(params)
    return this.http.get('http://beyont.in/angularapi/registration.php', {params})
  }

}
