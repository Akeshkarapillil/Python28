import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-favorite',
  templateUrl: './favorite.component.html',
  styleUrls: ['./favorite.component.css']
})
export class FavoriteComponent {

  @Input('isSelected') isFav: boolean = false;
  
  @Output('change') asd = new EventEmitter();

  onFavChange(){
    this.isFav = !this.isFav
    this.asd.emit({
      msg: "Hello",
      isSel: this.isFav
    })
  }

}
