import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsernameValidator } from './username.validator';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  form = new FormGroup({
    'account': new FormGroup(
      {
        'username': new FormControl('', 
          [
            Validators.required, 
            Validators.minLength(3), 
            Validators.maxLength(10),
            UsernameValidator.cannotContainSpace
          ],
            UsernameValidator.shouldBeUnique
          ),
        'password': new FormControl('', [Validators.required])
      }
    )
  })
  

  get account(){
    return this.form.get('account')
  }

  get username(){
    return this.account?.get('username')
  }

  get password(){
    return this.account?.get('password');
  }

  OnSubmit(){
    console.log(this.form.value)
  }


}
