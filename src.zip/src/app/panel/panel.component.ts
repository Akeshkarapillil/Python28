import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.css']
})
export class PanelComponent implements OnInit {

  constructor(public route : ActivatedRoute) { }

  ngOnInit(): void {
    // console.log("Hello");
    this.route.params.subscribe(params => {
      let id = params['id']
      let name = params?.['name']
      console.log(id);
      console.log(name)
    })
  }

}
