import { Component, ViewEncapsulation } from "@angular/core";
@Component({
    selector : "root-course",
    templateUrl: './course.component.html',
    styleUrls: ['./course.component.css'],
    encapsulation: ViewEncapsulation.Emulated
})

export class CourseComponent{
    // content = "An interface that is implemented by pipes in order to perform a transformation. Angular invokes the transform method with the value of a binding as the first argument, and any parameters as the second argument in list form."

    task = {
        "name": "Testing",
        "assignee": {
            "id": 100,
            "name": "Sam"
        }
    }
}