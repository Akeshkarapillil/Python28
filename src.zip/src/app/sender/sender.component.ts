import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { MediatorService } from '../mediator.service';

@Component({
  selector: 'app-sender',
  templateUrl: './sender.component.html',
  styleUrls: ['./sender.component.css']
})
export class SenderComponent implements OnInit {

  msg: any = {
    status: null,
    id: null
  }

  // constructor(private _ms: MediatorService) { }
  constructor(private _crud: CrudService) { }

  

  ngOnInit(): void {
  }

  onSubmit(value: any){
    // console.log(value);
    // this._ms.setData(value);
    // console.log(this._crud.register(value));
    this._crud.register(value).subscribe(res => {
      console.log(res);
      this.msg = res;
    })
  }

}
