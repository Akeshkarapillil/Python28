import { Component } from '@angular/core';

@Component({
  selector: 'contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent {

  paymentmethods = [
    {id : 0, value : "Debit Card"},
    {id : 1, value : "Credit Card"},
    {id : 2, value : "COD"}

  ]

  contactmodes =[
    {id: 0, mode: "Phone"},
    {id: 1, mode: "Email"},

  ]

  sub = true;

  onSubmit(form: any){
    console.log(form)
  }
  // onChange(x: any){
  //   console.log(x)
  // }

}
