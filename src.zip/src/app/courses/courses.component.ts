import { Component } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent {

  ViewMode = 'list'

  array = [
        { "id": 1, "name": "bill" },
        { "id": 2, "name": "bob" },
        { "id": 3, "name": "billy" }
    ]

    foo() {
        this.array = [
            { "id": 1, "name": "bill" },
            { "id": 2, "name": "asd" },
            { "id": 3, "name": "billy" }
        ]
    }

    identify(index: any, item: any) {
        return item.id;
    }

  // onModeChange(mode: string){
  //   this.ViewMode = mode
  // }

  // onRemove(index: number){
  //   this.courses.splice(index, 1)
  // }

  // identify(index: any, item: any){
  //   return item.id; 
  // }

}
