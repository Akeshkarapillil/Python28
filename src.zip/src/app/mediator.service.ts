import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MediatorService {

  private __datas: any = []

  constructor() { }

  setData(data: any){
    console.log(data);
    this.__datas.push(data);
  }

  getData(){
    return this.__datas;
  }

}
