import { ContactFormComponent } from './contact-form/contact-form.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FavoriteComponent } from './favorite/favorite.component';
import { SigninComponent } from './signin/signin.component';
import { PanelComponent } from './panel/panel.component';
import { ReceiverComponent } from './receiver/receiver.component';
import { SenderComponent } from './sender/sender.component';

const routes: Routes = [
  { path: '', component: FavoriteComponent},
  { path: 'contact', component: ContactFormComponent},
  { path: 'signin', component: SigninComponent},
  { path: 'panel/:id/:name', component: PanelComponent},
  { path: 'receiver', component: ReceiverComponent},
  { path: 'sender', component: SenderComponent},
  { path: '**', component: NotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
