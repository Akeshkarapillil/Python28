import { Component, OnInit } from '@angular/core';
import { MediatorService } from '../mediator.service';

@Component({
  selector: 'app-receiver',
  templateUrl: './receiver.component.html',
  styleUrls: ['./receiver.component.css']
})
export class ReceiverComponent implements OnInit {

  datas: any = ''

  constructor(private _ms: MediatorService) {}

  ngOnInit(): void {
    this.datas = this._ms.getData();
    // console.log(this._ms.getData());
  }

}
